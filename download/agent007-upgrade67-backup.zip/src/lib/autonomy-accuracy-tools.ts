/**
 * autonomy-accuracy-tools.ts — 8 tools for maximum autonomy, accuracy, and performance.
 * UPGRADE #67
 */
import type { ToolResult } from './tools'
import { dispatchTool } from './tools'
import { SUBAGENTS, getAllSubagents } from './subagents'

function ok(preview: string, result: string, artifacts?: any[]): ToolResult {
  return { ok: true, preview, result, artifacts }
}
function fail(result: string): ToolResult {
  return { ok: false, preview: result.slice(0, 120), result }
}

/* 1. TASK_DECOMPOSER */
export async function toolTaskDecomposer(args: any): Promise<ToolResult> {
  const { task, maxSubtasks = 10 } = args ?? {}
  if (!task) return fail('task_decomposer requires "task" (string).')
  const taskLower = task.toLowerCase()
  let taskType = 'general'
  if (/research|find|search|investigate/.test(taskLower)) taskType = 'research'
  else if (/build|create|make|develop/.test(taskLower)) taskType = 'build'
  else if (/write|draft|compose/.test(taskLower)) taskType = 'content'
  else if (/deploy|publish|launch/.test(taskLower)) taskType = 'deploy'
  else if (/fix|debug|repair/.test(taskLower)) taskType = 'fix'
  else if (/optimize|improve|enhance/.test(taskLower)) taskType = 'optimize'
  else if (/monitor|track|check|verify/.test(taskLower)) taskType = 'monitor'
  const templates: Record<string, string[]> = {
    research: ['Define research scope', 'Search primary sources (web_search, google_ai_search)', 'Search secondary sources (wikipedia, arxiv)', 'Cross-verify with accuracy_checker', 'Synthesize into structured report', 'Store findings in memory_store'],
    build: ['Gather requirements', 'Research existing solutions', 'Design architecture', 'Implement core functionality', 'Test the implementation', 'Document the solution'],
    content: ['Research the topic', 'Identify target audience', 'Create outline', 'Draft content', 'Review with quality_scorer', 'Format for platform'],
    deploy: ['Verify build passes', 'Run pre-deploy tests', 'Execute deployment', 'Verify live (test_endpoint)', 'Monitor for errors', 'Report status'],
    fix: ['Reproduce the issue', 'Identify root cause (source_read, view_error_logs)', 'Design the fix', 'Apply fix (file_write)', 'Verify fix works', 'Deploy the fix'],
    optimize: ['Measure current performance', 'Identify bottlenecks', 'Research optimization techniques', 'Apply optimizations', 'Measure new performance', 'Report improvement'],
    monitor: ['Define monitoring scope', 'Set up monitoring config', 'Take initial measurements', 'Compare against thresholds', 'Identify anomalies', 'Report status + recommendations'],
    general: ['Understand requirements', 'Gather information', 'Plan approach', 'Execute plan', 'Verify results', 'Report outcome'],
  }
  const subtasks = (templates[taskType] ?? templates.general).slice(0, maxSubtasks).map((desc, i) => ({ step: i + 1, description: desc, status: 'pending' }))
  const result = { task, taskType, totalSubtasks: subtasks.length, subtasks, estimatedIterations: subtasks.length }
  return ok(
    `${subtasks.length} subtasks for ${taskType} task`,
    `Task decomposed into ${subtasks.length} subtasks (type: ${taskType}):\n${subtasks.map((s) => `  ${s.step}. ${s.description}`).join('\n')}`,
    [{ type: 'text', data: JSON.stringify(result, null, 2), label: 'Task decomposition' }]
  )
}

/* 2. RESULT_VERIFIER */
export async function toolResultVerifier(args: any): Promise<ToolResult> {
  const { result, expected, criteria, strict = false } = args ?? {}
  if (!result) return fail('result_verifier requires "result".')
  const resultStr = typeof result === 'string' ? result : JSON.stringify(result)
  const checks: any[] = []
  checks.push({ name: 'non_empty', passed: resultStr.trim().length > 0, detail: `Length: ${resultStr.length}` })
  if (expected) {
    const exp = typeof expected === 'string' ? expected : JSON.stringify(expected)
    const contains = resultStr.toLowerCase().includes(exp.toLowerCase())
    checks.push({ name: 'contains_expected', passed: contains, detail: contains ? 'Found' : 'Not found' })
  }
  if (Array.isArray(criteria)) {
    for (const c of criteria) {
      if (c?.field && c?.operator && c?.value !== undefined) {
        const fv = (result as any)?.[c.field] ?? resultStr
        let passed = false
        if (c.operator === '==') passed = fv == c.value
        else if (c.operator === '!=') passed = fv != c.value
        else if (c.operator === '>') passed = Number(fv) > Number(c.value)
        else if (c.operator === '<') passed = Number(fv) < Number(c.value)
        else if (c.operator === 'contains') passed = String(fv).includes(String(c.value))
        checks.push({ name: `criteria_${c.field}`, passed, detail: `${c.field} ${c.operator} ${c.value}` })
      }
    }
  }
  if (!strict) {
    const errors = ['error', 'failed', 'undefined', 'exception']
    const hasErr = errors.some((e) => resultStr.toLowerCase().includes(e))
    checks.push({ name: 'no_error_indicators', passed: !hasErr, detail: hasErr ? 'Has errors' : 'Clean' })
  }
  const passedCount = checks.filter((c) => c.passed).length
  const score = Math.round((passedCount / checks.length) * 100)
  const allPassed = passedCount === checks.length
  return ok(
    `${passedCount}/${checks.length} passed (${score}%)`,
    `${allPassed ? 'PASSED' : 'PARTIAL'} — ${passedCount}/${checks.length} checks (${score}%)\n${checks.map((c) => `  ${c.passed ? 'OK' : 'FAIL'} ${c.name}: ${c.detail}`).join('\n')}`,
    [{ type: 'text', data: JSON.stringify({ allPassed, score, checks }), label: 'Verification' }]
  )
}

/* 3. PARALLEL_SUBAGENT_DISPATCHER */
export async function toolParallelSubagentDispatcher(args: any, ctx?: any): Promise<ToolResult> {
  const { dispatches } = args ?? {}
  if (!Array.isArray(dispatches) || dispatches.length === 0) return fail('parallel_subagent_dispatcher requires "dispatches" array.')
  const allSubs = await getAllSubagents({ includeDisabled: false }).catch(() => SUBAGENTS)
  const valid: any[] = []
  for (const d of dispatches) {
    if (!d?.id || !d?.task) continue
    const sub = allSubs.find((s: any) => s.id === d.id || s.name.toLowerCase() === d.id.toLowerCase())
    if (sub && sub.enabled !== false) valid.push({ id: sub.id, task: d.task, name: sub.name })
  }
  if (valid.length === 0) return fail('No valid subagents to dispatch.')
  const startTime = Date.now()
  const { runSubagent } = await import('./subagents')
  const results = await Promise.allSettled(
    valid.map(async (d) => {
      const r = await runSubagent({
        subagentId: d.id, task: d.task, dispatchId: `par_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        attachments: ctx?.attachments ?? [], language: ctx?.language ?? 'en',
        emit: ctx?.emit ?? (async () => {}), parentConversationId: ctx?.conversationId ?? 'parallel',
      })
      return { id: d.id, name: d.name, task: d.task, answer: r.answer }
    })
  )
  const elapsedMs = Date.now() - startTime
  const succeeded = results.filter((r) => r.status === 'fulfilled').length
  const summary = results.map((r, i) => {
    if (r.status === 'fulfilled') return `OK ${valid[i].name}: ${r.value.answer?.slice(0, 80) ?? 'no response'}`
    return `FAIL ${valid[i].name}: ${r.reason?.message ?? 'error'}`
  }).join('\n')
  return ok(
    `${succeeded}/${results.length} in ${elapsedMs}ms`,
    `Parallel dispatch: ${succeeded}/${results.length} succeeded in ${elapsedMs}ms\n${summary}`,
    [{ type: 'text', data: JSON.stringify({ results: results.map((r, i) => ({ id: valid[i].id, name: valid[i].name, status: r.status, answer: r.status === 'fulfilled' ? r.value.answer : null })), elapsedMs }), label: 'Parallel results' }]
  )
}

/* 4. CONTEXT_COMPRESSOR */
export async function toolContextCompressor(args: any): Promise<ToolResult> {
  const { messages, maxTokens = 8000 } = args ?? {}
  if (!Array.isArray(messages)) return fail('context_compressor requires "messages" array.')
  const est = (t: string) => Math.ceil((t ?? '').length / 4)
  let total = messages.reduce((s: number, m: any) => s + est(m.content ?? ''), 0)
  if (total <= maxTokens) return ok(`${total}/${maxTokens} tokens`, `Context within budget — ${total} tokens. No compression needed.`)
  const system = messages.filter((m: any) => m.role === 'system')
  const firstUser = messages.find((m: any) => m.role === 'user')
  const last5 = messages.slice(-5)
  const dropped = messages.length - system.length - 1 - last5.length
  const compressed = [...system, { role: 'user', content: `[COMPRESSED] ${dropped} messages dropped. First: ${firstUser?.content?.slice(0, 200) ?? 'N/A'}` }, ...last5]
  const newTotal = compressed.reduce((s: number, m: any) => s + est(m.content ?? ''), 0)
  const reduction = Math.round(((total - newTotal) / total) * 100)
  return ok(`${total} -> ${newTotal} (${reduction}%)`, `Compressed: ${total} -> ${newTotal} tokens (${reduction}% reduction). ${dropped} messages summarized.`)
}

/* 5. SMART_RETRY_ENGINE */
export async function toolSmartRetryEngine(args: any, ctx?: any): Promise<ToolResult> {
  const { toolName, originalArgs = {}, originalError = '', maxRetries = 3 } = args ?? {}
  if (!toolName) return fail('smart_retry_engine requires "toolName".')
  const toolCtx = ctx ?? { attachments: [], language: 'en', conversationId: 'retry' }
  const attempts: any[] = []
  let currentArgs = { ...originalArgs }
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    const modified = { ...currentArgs }
    if (attempt === 1 && modified.query?.length > 100) modified.query = modified.query.slice(0, 100)
    if (attempt === 2) {
      if (originalError.toLowerCase().includes('timeout')) modified.timeout = 30000
      if (originalError.toLowerCase().includes('rate')) modified.recency_days = 30
    }
    if (attempt === 3 && modified.query) modified.query = modified.query.split(' ').slice(0, 3).join(' ')
    try {
      const result = await dispatchTool(toolName, modified, toolCtx)
      attempts.push({ attempt, ok: result.ok, preview: result.preview })
      if (result.ok) return ok(`Succeeded on attempt ${attempt}`, `Smart retry succeeded on attempt ${attempt}/${maxRetries}.\n${attempts.map((a) => `  ${a.attempt}: ${a.ok ? 'OK' : 'FAIL'} ${a.preview}`).join('\n')}\n\nResult: ${result.result}`)
      currentArgs = modified
    } catch (e: any) {
      attempts.push({ attempt, ok: false, preview: e?.message ?? 'exception' })
    }
  }
  return fail(`Smart retry failed after ${maxRetries} attempts.\n${attempts.map((a) => `  ${a.attempt}: ${a.ok ? 'OK' : 'FAIL'} ${a.preview}`).join('\n')}`)
}

/* 6. PROGRESS_TRACKER */
export async function toolProgressTracker(args: any): Promise<ToolResult> {
  const { action, taskId, step, totalSteps, status, note } = args ?? {}
  const _g: any = globalThis as any
  if (!_g.__progressTracker) _g.__progressTracker = new Map()
  const store: Map<string, any> = _g.__progressTracker
  if (action === 'init') {
    if (!taskId) return fail('init requires taskId + totalSteps')
    store.set(taskId, { taskId, totalSteps: totalSteps ?? 0, currentStep: 0, steps: [], startedAt: new Date().toISOString(), status: 'in_progress' })
    return ok(`Task ${taskId} initialized`, `Progress tracker initialized — ${totalSteps} steps.`)
  }
  if (action === 'update') {
    if (!taskId) return fail('update requires taskId')
    const p = store.get(taskId)
    if (!p) return fail(`Task ${taskId} not found`)
    p.currentStep = step ?? p.currentStep + 1
    p.steps.push({ step: p.currentStep, status: status ?? 'done', note, timestamp: new Date().toISOString() })
    if (p.currentStep >= p.totalSteps) p.status = 'completed'
    const pct = Math.round((p.currentStep / p.totalSteps) * 100)
    return ok(`Step ${p.currentStep}/${p.totalSteps} (${pct}%)`, `Progress: step ${p.currentStep}/${p.totalSteps} (${pct}%) — ${status ?? 'done'}`)
  }
  if (action === 'status') {
    if (!taskId) return fail('status requires taskId')
    const p = store.get(taskId)
    if (!p) return fail(`Task ${taskId} not found`)
    const pct = Math.round((p.currentStep / p.totalSteps) * 100)
    return ok(`${pct}% — ${p.status}`, `Task ${taskId}: ${p.currentStep}/${p.totalSteps} (${pct}%) — ${p.status}`)
  }
  if (action === 'list') {
    const tasks = Array.from(store.entries()).map(([id, p]: any) => `${id}: ${p.currentStep}/${p.totalSteps} — ${p.status}`)
    return ok(`${tasks.length} tasks`, `Active tasks (${tasks.length}):\n${tasks.join('\n') || '(none)'}`)
  }
  return fail(`Unknown action: ${action}. Supported: init, update, status, list.`)
}

/* 7. QUALITY_SCORER */
export async function toolQualityScorer(args: any): Promise<ToolResult> {
  const { answer, question } = args ?? {}
  if (!answer) return fail('quality_scorer requires "answer".')
  const a = typeof answer === 'string' ? answer : JSON.stringify(answer)
  const q = typeof question === 'string' ? question : ''
  const checks: any[] = []
  // relevance (0-25)
  let rel = 15
  if (q) {
    const qWords = q.toLowerCase().split(/\s+/).filter((w) => w.length > 3)
    const aLower = a.toLowerCase()
    const matched = qWords.filter((w) => aLower.includes(w))
    rel = Math.min(25, Math.round((matched.length / Math.max(1, qWords.length)) * 25))
  }
  checks.push({ name: 'relevance', score: rel, max: 25 })
  // completeness (0-25)
  const comp = a.length > 2000 ? 25 : a.length > 1000 ? 20 : a.length > 500 ? 15 : a.length > 200 ? 10 : a.length > 50 ? 5 : 0
  checks.push({ name: 'completeness', score: comp, max: 25 })
  // accuracy (0-20)
  let acc = 0
  if (/\d+/.test(a)) acc += 5
  if (/https?:\/\/|source|according to/i.test(a)) acc += 10
  if (/might|could|approximately/i.test(a)) acc += 5
  checks.push({ name: 'accuracy', score: acc, max: 20 })
  // clarity (0-15)
  let clar = 0
  if (/#{1,3}\s|^\s*[-*]\s|\d+\.\s/m.test(a)) clar += 10
  if (a.split('\n\n').length > 1) clar += 5
  checks.push({ name: 'clarity', score: clar, max: 15 })
  // actionability (0-15)
  let act = 0
  if (/next step|recommend|action|implement|deploy|create/i.test(a)) act += 10
  if (/example|for instance|e\.g\./i.test(a)) act += 5
  checks.push({ name: 'actionability', score: act, max: 15 })
  const total = checks.reduce((s, c) => s + c.score, 0)
  const maxTotal = checks.reduce((s, c) => s + c.max, 0)
  const pct = Math.round((total / maxTotal) * 100)
  const grade = pct >= 90 ? 'A' : pct >= 80 ? 'B' : pct >= 70 ? 'C' : pct >= 60 ? 'D' : 'F'
  return ok(`${pct}% (Grade ${grade})`, `Quality: ${total}/${maxTotal} (${pct}%) — Grade ${grade}\n${checks.map((c) => `  ${c.name}: ${c.score}/${c.max}`).join('\n')}${pct < 70 ? '\n\nScore below 70% — refine the answer.' : ''}`)
}

/* 8. AUTONOMOUS_EXECUTOR */
export async function toolAutonomousExecutor(args: any, ctx?: any): Promise<ToolResult> {
  const { task, maxSteps = 10, verify = true } = args ?? {}
  if (!task) return fail('autonomous_executor requires "task".')
  const startTime = Date.now()
  const log: any[] = []
  // Step 1: decompose
  const decomp = await toolTaskDecomposer({ task, maxSubtasks: maxSteps })
  log.push({ step: 1, action: 'task_decomposer', ok: decomp.ok, preview: decomp.preview })
  if (!decomp.ok) return fail(`Failed at decomposition: ${decomp.result}`)
  // Step 2: init progress
  const taskId = `auto_${Date.now()}`
  await toolProgressTracker({ action: 'init', taskId, totalSteps: maxSteps })
  log.push({ step: 2, action: 'progress_tracker init', ok: true, preview: 'initialized' })
  // Steps 3-N: execute (simulated — real execution would use the orchestrator)
  const subtasks = decomp.artifacts?.[0]?.data ? JSON.parse(decomp.artifacts[0].data).subtasks : []
  const results: any[] = []
  for (let i = 0; i < Math.min(subtasks.length, maxSteps - 2); i++) {
    const stepNum = i + 3
    results.push({ subtask: subtasks[i].description, status: 'pending' })
    await toolProgressTracker({ action: 'update', taskId, step: stepNum, status: 'pending', note: subtasks[i].description })
    log.push({ step: stepNum, action: subtasks[i].description.slice(0, 50), ok: true, preview: 'pending' })
  }
  // Final: verify
  if (verify) {
    const verResult = await toolResultVerifier({ result: results.map((r) => r.subtask).join('\n') })
    log.push({ step: log.length + 1, action: 'result_verifier', ok: verResult.ok, preview: verResult.preview })
  }
  const elapsedMs = Date.now() - startTime
  return ok(
    `${results.length} subtasks in ${elapsedMs}ms`,
    `Autonomous execution: ${results.length} subtasks in ${elapsedMs}ms.\nLog:\n${log.map((l) => `  Step ${l.step}: ${l.action} — ${l.ok ? 'OK' : 'FAIL'}`).join('\n')}\n\nSubtasks:\n${results.map((r, i) => `  ${i + 1}. [${r.status}] ${r.subtask}`).join('\n')}`
  )
}
