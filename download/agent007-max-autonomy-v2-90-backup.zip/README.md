# Agent007 AI — Owner Backup

Generated: 2026-07-17T01:36:27.712Z
Label: upgrade90-max-autonomy-v2

## Contents

1. agent007-backup-2026-07-17T01-36-27-132Z-upgrade90-max-autonomy-v2.json — full structured backup
   - All 33 DB tables (or empty if DB unavailable)
   - All 86 permanent upgrades
   - Capabilities snapshot
   - Config metadata

2. Source files (local dev only — Vercel doesn't bundle them):
   - src/lib/agent.ts
   - src/lib/orchestrator.ts
   - src/lib/tools.ts
   - src/lib/subagents.ts
   - src/middleware.ts
   - src/app/api/owner-backup/route.ts
   - vercel.json
   - prisma/schema.prisma
   - package.json
   - + more

## Auth

This backup was downloaded via /api/owner-backup?token=<OWNER_BACKUP_TOKEN>
Only the owner with the correct token can download backups.

## Stats

- Database tables: 33
- Total rows: 1431
- Upgrades: 86
- JSON size: 3.17 MB