import { NextRequest, NextResponse } from 'next/server'
import { toolTestRunner } from '@/lib/tool-testing-coordination'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

/**
 * POST /api/tools/test
 *
 * UPGRADE #176 fix #1: This route file was claimed created in #172
 * (commit e56406a) but was NEVER actually committed — `git show e56406a
 * --stat` confirms the file is missing from that commit. The production
 * endpoint still worked because Vercel was serving a stale deployment
 * from before the file was deleted from source.
 *
 * This commit creates the file PROPERLY so future deploys will continue
 * to serve the route. Wraps the existing `toolTestRunner` function from
 * src/lib/tool-testing-coordination.ts:55.
 *
 * Lets you invoke any tool registered in TOOL_REGISTRY with custom args.
 * Useful for:
 *   - Live verification that a tool returns REAL data (not Math.random)
 *   - Quick debugging of tool args format
 *   - Smoke testing after deploys
 *
 * SECURITY: Public (whitelisted in middleware matcher: tools/test|).
 * No user data is exposed. Costs LLM tokens for tools that call the LLM
 * (accuracy_checker, autonomous_decision_maker, etc.). The rate limiter
 * in middleware will throttle anonymous IPs.
 *
 * Body:
 *   {
 *     "tool": "<tool_name>",      // required — e.g. "accuracy_checker"
 *     "args": {...},              // optional — tool-specific args
 *     "timeout": 30               // optional — seconds (default 30, max 60)
 *   }
 *
 * Response:
 *   {
 *     "ok": true|false,
 *     "preview": "...",
 *     "result": "TOOL TEST\nTool: ...\nArgs: ...\nResult: ...\nElapsed: ...ms\n\n...",
 *     "elapsed_ms": 1234
 *   }
 */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}))
  const tool = (body?.tool ?? '').toString().trim()
  if (!tool) {
    return NextResponse.json(
      { ok: false, error: 'Missing "tool" parameter. Example: {"tool":"accuracy_checker","args":{"claim":"The capital of France is Paris"}}' },
      { status: 400 }
    )
  }
  // Cap timeout at 60s (maxDuration is 60s for this route)
  const timeout = Math.min(60, Math.max(5, Number(body?.timeout ?? 30)))
  const args = body?.args ?? {}

  const start = Date.now()
  try {
    const result = await toolTestRunner({ tool, args, timeout })
    return NextResponse.json({
      ok: result.ok,
      preview: result.preview,
      result: result.result,
      elapsed_ms: Date.now() - start,
    })
  } catch (e: any) {
    return NextResponse.json(
      {
        ok: false,
        error: e?.message ?? String(e),
        elapsed_ms: Date.now() - start,
      },
      { status: 500 }
    )
  }
}
