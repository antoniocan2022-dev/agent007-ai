import ZAI from 'z-ai-web-dev-sdk'
import { db } from "./db"
import vm from 'node:vm'
import path from 'node:path'
import { promises as fs } from 'node:fs'
import { recallMemories, upsertMemory, type MemoryRecord } from '@/lib/memory'

const UPLOAD_DIR = '/home/z/my-project/download/uploads'

export interface AttachmentMeta {
  filename: string
  originalName: string
  mimeType: string
  size: number
  // for images: data URL of the uploaded file (so vision tool can read it)
  dataUrl?: string
  // for text-like files: inline text content
  textContent?: string
}

export interface ToolContext {
  attachments: AttachmentMeta[]
  language: 'en' | 'zh'
}

export interface ToolResult {
  /** Short, human-readable preview for the UI timeline (markdown allowed) */
  preview: string
  /** Full result string fed back to the LLM */
  result: string
  /** Optional artifacts (e.g. generated image data URL) for UI rendering */
  artifacts?: Array<{
    type: 'image' | 'text' | 'link'
    data: string
    label?: string
  }>
  /** Whether the tool succeeded */
  ok: boolean
}

let _zai: ZAI | null = null
async function getZai(): Promise<ZAI> {
  if (!_zai) _zai = await ZAI.create()
  return _zai
}

/* ------------------------------------------------------------------ *
 * 1-hour in-memory cache for web_search + page_reader (#11).
 *
 * Only successful results are cached. image_gen / vision / code_exec /
 * memory_* / file_read / wikipedia_* / free_apis_directory are NOT cached
 * (either they're non-deterministic, expensive-to-cache, or already cheap).
 * ------------------------------------------------------------------ */
interface CacheEntry {
  result: ToolResult
  at: number
}
const _toolCache = new Map<string, CacheEntry>()
const CACHE_TTL_MS = 60 * 60 * 1000 // 1 hour

function cacheKey(toolName: string, args: any): string {
  return toolName + ':' + JSON.stringify(args ?? {})
}

function getCached(toolName: string, args: any): ToolResult | null {
  const k = cacheKey(toolName, args)
  const e = _toolCache.get(k)
  if (!e) return null
  if (Date.now() - e.at > CACHE_TTL_MS) {
    _toolCache.delete(k)
    return null
  }
  return e.result
}

function setCached(toolName: string, args: any, result: ToolResult): void {
  // Only cache successful results
  if (!result.ok) return
  _toolCache.set(cacheKey(toolName, args), { result, at: Date.now() })
}

/* ----------------------------- Web search ----------------------------- */
export async function toolWebSearch(
  args: { query?: string; num?: number; recency_days?: number },
  _ctx: ToolContext
): Promise<ToolResult> {
  const query = (args?.query ?? '').toString().trim()
  if (!query) return badResult('Missing "query" argument for web_search')
  // Cache lookup (1-hour TTL)
  const cached = getCached('web_search', args)
  if (cached) {
    return {
      ...cached,
      preview: '[cached] ' + cached.preview,
    }
  }
  try {
    const zai = await getZai()
    const results = await zai.functions.invoke('web_search', {
      query,
      num: Math.min(Math.max(args.num ?? 5, 1), 10),
      recency_days: args.recency_days,
    })
    if (!Array.isArray(results) || results.length === 0) {
      return okResult(
        `No results found for "${query}"`,
        `No web search results found for query: "${query}".`
      )
    }
    const formatted = results
      .map((r: any, i: number) => {
        const snip = (r.snippet || '').toString().slice(0, 400)
        return `${i + 1}. **${r.name || r.url}**\n   URL: ${r.url}\n   ${snip}${r.date ? `\n   Date: ${r.date}` : ''}`
      })
      .join('\n\n')
    const preview = results
      .slice(0, 3)
      .map((r: any) => `• ${r.name || r.url}`)
      .join('\n')
    const out = okResult(preview, formatted)
    setCached('web_search', args, out)
    return out
  } catch (e: any) {
    return badResult(`web_search failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Page reader ---------------------------- */
export async function toolPageReader(
  args: { url?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const url = (args?.url ?? '').toString().trim()
  if (!url) return badResult('Missing "url" argument for page_reader')
  // Cache lookup (1-hour TTL)
  const cached = getCached('page_reader', args)
  if (cached) {
    return {
      ...cached,
      preview: '[cached] ' + cached.preview,
    }
  }

  // URL validation — pre-check with a HEAD request to avoid wasting the
  // page_reader call (and an LLM iteration) on 404s / 5xxs. This was a
  // recurring issue during cybersecurity testing where the agent would
  // try URLs like "owasp.org/Top10/2025/0x01_2025-Broken_Access_Control"
  // that returned 404, wasting iterations.
  try {
    const urlObj = new URL(url)
    // Only validate http/https URLs
    if (urlObj.protocol === 'http:' || urlObj.protocol === 'https:') {
      const controller = new AbortController()
      const timeout = setTimeout(() => controller.abort(), 5000)
      try {
        const headRes = await fetch(url, {
          method: 'HEAD',
          signal: controller.signal,
          redirect: 'follow',
          headers: { 'User-Agent': 'Agent007-AI/2.0' },
        })
        clearTimeout(timeout)
        // 405 = server doesn't support HEAD (common) — allow these through
        // 403 = often blocks bots but page_reader may still work — allow through
        if (headRes.status === 404 || headRes.status >= 500) {
          const skip = `URL returned HTTP ${headRes.status} — skipping page_reader to save iterations. Try a different URL or use web_search to find the correct one.`
          return badResult(skip)
        }
      } catch (headErr: any) {
        // HEAD failed (timeout, CORS, DNS) — don't block, fall through to page_reader
        clearTimeout(timeout)
      }
    }
  } catch {
    // Invalid URL — fall through to page_reader which will report the error
  }

  try {
    const zai = await getZai()
    const res: any = await zai.functions.invoke('page_reader', { url })
    const html = res?.data?.html ?? ''
    const title = res?.data?.title ?? url
    const text = stripHtml(html).slice(0, 6000)
    const out = okResult(
      `Read page: ${title}\n${text.slice(0, 400)}...`,
      `Page: ${title}\nURL: ${url}\n\n${text}`
    )
    setCached('page_reader', args, out)
    return out
  } catch (e: any) {
    return badResult(`page_reader failed: ${e?.message ?? String(e)}`)
  }
}

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
}

/* ----------------------------- Image generation ----------------------- */
const VALID_SIZES = [
  '1024x1024',
  '768x1344',
  '864x1152',
  '1344x768',
  '1152x864',
  '1440x720',
  '720x1440',
] as const

export async function toolImageGen(
  args: { prompt?: string; size?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const prompt = (args?.prompt ?? '').toString().trim()
  if (!prompt) return badResult('Missing "prompt" argument for image_gen')
  const size = (VALID_SIZES as readonly string[]).includes(args.size ?? '')
    ? (args.size as (typeof VALID_SIZES)[number])
    : '1024x1024'
  try {
    const zai = await getZai()
    const resp = await zai.images.generations.create({ prompt, size })
    const b64 = resp?.data?.[0]?.base64
    if (!b64) return badResult('image_gen returned no data')
    const dataUrl = `data:image/png;base64,${b64}`
    return {
      ok: true,
      preview: `Generated image (${size}): "${prompt.slice(0, 80)}"`,
      result: `Image generated successfully. The image is embedded in this message as a PNG data URL (omitted here for brevity). Prompt: "${prompt}". Size: ${size}.`,
      artifacts: [{ type: 'image', data: dataUrl, label: prompt.slice(0, 80) }],
    }
  } catch (e: any) {
    return badResult(`image_gen failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Vision --------------------------------- */
export async function toolVision(
  args: { prompt?: string; image_index?: number },
  ctx: ToolContext
): Promise<ToolResult> {
  const prompt = (args?.prompt ?? 'Describe this image in detail.').toString().trim()
  const idx = Number(args?.image_index ?? 0)
  const images = ctx.attachments.filter((a) => a.mimeType.startsWith('image/') && a.dataUrl)
  if (images.length === 0) {
    return badResult(
      'No attached image available for vision analysis. Ask the user to attach an image first.'
    )
  }
  const img = images[Math.min(Math.max(idx, 0), images.length - 1)]
  try {
    const zai = await getZai()
    const visionResp: any = await zai.chat.completions.createVision({
      model: 'glm-4.5v',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url: img.dataUrl ?? "" } },
          ],
        },
      ],
    })
    const text =
      visionResp?.choices?.[0]?.message?.content ??
      visionResp?.choices?.[0]?.message?.reasoning_content ??
      ''
    return okResult(`Vision: ${(text as string).slice(0, 200)}`, text as string)
  } catch (e: any) {
    return badResult(`vision failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Code execution ------------------------- */
export async function toolCodeExec(
  args: { code?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const raw = (args?.code ?? '').toString()
  if (!raw.trim()) return badResult('Missing "code" argument for code_exec')

  const logs: string[] = []
  const sandboxConsole = {
    log: (...a: any[]) => logs.push(a.map(stringifyForLog).join(' ')),
    error: (...a: any[]) => logs.push('[error] ' + a.map(stringifyForLog).join(' ')),
    warn: (...a: any[]) => logs.push('[warn] ' + a.map(stringifyForLog).join(' ')),
    info: (...a: any[]) => logs.push(a.map(stringifyForLog).join(' ')),
  }

  // Decide expression vs statement form
  let codeToRun = raw.trim()
  let isExpression = false
  try {
    // Try parsing as expression first
    new Function(`return (${codeToRun})`)
    isExpression = true
  } catch {
    isExpression = false
  }

  // Wrap in an IIFE so `return` is legal at the top of the function body.
  // vm.Script does NOT allow top-level return statements, so we MUST wrap.
  const wrapped = isExpression
    ? `"use strict";\n(() => { return (${codeToRun}); })()`
    : `"use strict";\n(() => {\n${codeToRun}\n})()`

  const sandbox = {
    Math,
    JSON,
    console: sandboxConsole,
    Date,
    Array,
    Object,
    String,
    Number,
    Boolean,
    Math_utils: Math,
    parseInt,
    parseFloat,
    isNaN,
    isFinite,
    undefined,
  }

  try {
    const script = new vm.Script(wrapped, { filename: 'sandbox.js' })
    const context = vm.createContext(sandbox)
    let value: any
    try {
      value = script.runInContext(context, { timeout: 3000 } as any)
    } catch (err: any) {
      const msg = err?.message ?? String(err)
      return badResult(`Runtime error: ${msg}\nConsole output:\n${logs.join('\n')}`)
    }
    let valueStr: string
    try {
      valueStr =
        value === undefined ? 'undefined' : typeof value === 'string' ? value : JSON.stringify(value, null, 2)
      if (valueStr === undefined) valueStr = 'undefined'
    } catch {
      valueStr = String(value)
    }
    const resultText = `Console output:\n${logs.join('\n')}${logs.length ? '\n' : ''}\nReturn value:\n${valueStr}`
    const preview = `console: ${logs.length} line(s) • returns: ${valueStr.slice(0, 80)}`
    return okResult(preview, resultText)
  } catch (e: any) {
    return badResult(`code_exec failed: ${e?.message ?? String(e)}`)
  }
}

function stringifyForLog(v: any): string {
  if (typeof v === 'string') return v
  try {
    return JSON.stringify(v)
  } catch {
    return String(v)
  }
}

/* ----------------------------- Memory store --------------------------- */
export async function toolMemoryStore(
  args: { key?: string; value?: any; category?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const key = (args?.key ?? '').toString().trim()
  // Coerce value to a string before storage. If the LLM accidentally passed
  // a JS object/array, JSON.stringify it so we never end up with "[object Object]"
  // in the Memory table. Numbers/booleans become their string form. Strings stay as-is.
  const rawValue = args?.value
  const value =
    rawValue === null || rawValue === undefined
      ? ''
      : typeof rawValue === 'string'
      ? rawValue.trim()
      : typeof rawValue === 'object'
      ? JSON.stringify(rawValue)
      : String(rawValue).trim()
  const category = (args?.category ?? 'general').toString().trim()
  if (!key || !value) return badResult('memory_store requires both "key" and "value"')
  try {
    const rec = await upsertMemory(key, value, category)
    return okResult(
      `Stored memory [${rec.category}] "${rec.key}"`,
      `Memory stored successfully. Key: "${rec.key}", Value: "${rec.value}", Category: "${rec.category}".`
    )
  } catch (e: any) {
    return badResult(`memory_store failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Memory recall -------------------------- */
export async function toolMemoryRecall(
  args: { query?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const query = (args?.query ?? '').toString().trim()
  try {
    const memories: MemoryRecord[] = await recallMemories(query, 12)
    if (!memories.length) {
      return okResult(
        'No memories matched.',
        `No previously stored memories matched query "${query}".`
      )
    }
    const formatted = memories
      .map((m) => `- [${m.category}] ${m.key}: ${m.value}`)
      .join('\n')
    return okResult(
      `Recalled ${memories.length} memor${memories.length === 1 ? 'y' : 'ies'}`,
      `Recalled memories:\n${formatted}`
    )
  } catch (e: any) {
    return badResult(`memory_recall failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- File read ------------------------------ */
export async function toolFileRead(
  args: { filename?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const filename = (args?.filename ?? '').toString().trim()
  if (!filename) return badResult('Missing "filename" argument for file_read')
  try {
    const safe = path.basename(filename) // strip any path traversal
    let full = path.join(UPLOAD_DIR, safe)
    // If exact name doesn't exist, try a suffix match on uploads (UUID-prefixed names)
    try {
      await fs.access(full)
    } catch {
      const files = await fs.readdir(UPLOAD_DIR)
      const match = files.find((f) => f.endsWith('-' + safe) || f.endsWith(safe))
      if (match) full = path.join(UPLOAD_DIR, match)
    }
    const buf = await fs.readFile(full)
    const isText =
      /\.(txt|md|csv|json|js|ts|tsx|jsx|html|css|xml|yaml|yml|log|py|go|rs|java|c|cpp|h)$/i.test(
        safe
      )
    if (isText) {
      const text = buf.toString('utf8').slice(0, 20000)
      return okResult(
        `Read ${safe} (${buf.length} bytes)`,
        `File: ${safe} (${buf.length} bytes)\n\n${text}`
      )
    }
    if (/\.(png|jpe?g|gif|webp|bmp)$/i.test(safe)) {
      const ext = path.extname(safe).slice(1).toLowerCase()
      const mime = ext === 'jpg' ? 'jpeg' : ext
      const b64 = buf.toString('base64')
      const dataUrl = `data:image/${mime};base64,${b64}`
      return {
        ok: true,
        preview: `Read image file: ${safe}`,
        result: `Image file ${safe} loaded (${buf.length} bytes). Use vision tool to analyze it if needed.`,
        artifacts: [{ type: 'image', data: dataUrl, label: safe }],
      }
    }
    return okResult(
      `Read binary ${safe} (${buf.length} bytes)`,
      `File ${safe} is binary (${buf.length} bytes). Cannot display inline; the agent can describe its purpose.`
    )
  } catch (e: any) {
    return badResult(`file_read failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Wikipedia search ----------------------- */
/**
 * Search Wikipedia's free API. No API key required.
 *
 * NOTE: We deliberately omit `origin=*` from the URL. That parameter is only
 * needed for cross-origin browser requests (it triggers Wikimedia's CORS
 * bypass which, combined with Node.js's undici TLS fingerprint, gets blocked
 * with HTTP 403 by Wikimedia's bot detection in some sandbox environments).
 * Server-side requests work fine without it.
 *
 * The User-Agent follows Wikimedia's policy (https://meta.wikimedia.org/wiki/User-Agent_policy):
 * a descriptive UA with a contact URL. This also helps avoid 403 blocks.
 *
 * Docs: https://www.mediawiki.org/wiki/API:Search
 */
export async function toolWikipediaSearch(
  args: { query?: string; limit?: number },
  _ctx: ToolContext
): Promise<ToolResult> {
  const query = (args?.query ?? '').toString().trim()
  if (!query) return badResult('Missing "query" argument for wikipedia_search')
  const limit = Math.min(Math.max(args.limit ?? 5, 1), 20)
  try {
    const url =
      'https://en.wikipedia.org/w/api.php?action=query&list=search' +
      `&srsearch=${encodeURIComponent(query)}` +
      `&srlimit=${limit}` +
      '&format=json'
    const resp = await fetch(url, {
      headers: { 'User-Agent': 'Agent007-AI/1.0 (https://github.com/agent007; research bot)' },
    })
    if (!resp.ok) return badResult(`wikipedia_search HTTP ${resp.status}`)
    const data: any = await resp.json()
    const items: any[] = data?.query?.search ?? []
    if (items.length === 0) {
      return okResult(
        `No Wikipedia articles matched "${query}".`,
        `No Wikipedia articles found for query: "${query}".`
      )
    }
    const formatted = items
      .map((it, i) => {
        const title = it.title ?? ''
        const snip = (it.snippet ?? '').toString().replace(/<[^>]+>/g, '').slice(0, 400)
        const url = `https://en.wikipedia.org/?curid=${it.pageid}`
        return `${i + 1}. **${title}**\n   URL: ${url}\n   ${snip}`
      })
      .join('\n\n')
    const preview = items
      .slice(0, 3)
      .map((it) => `• ${it.title}`)
      .join('\n')
    return okResult(preview, formatted)
  } catch (e: any) {
    return badResult(`wikipedia_search failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Wikipedia read ------------------------- */
/**
 * Read a full Wikipedia article. Uses the parse API to get wikitext,
 * then strips wikitext markup to readable plain text. Truncated to 8000 chars.
 *
 * Same `origin=*` omission + descriptive UA as `toolWikipediaSearch` —
 * see that function's docstring for rationale.
 *
 * Docs: https://www.mediawiki.org/wiki/API:Parsing_wikitext
 */
export async function toolWikipediaRead(
  args: { title?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const title = (args?.title ?? '').toString().trim()
  if (!title) return badResult('Missing "title" argument for wikipedia_read')
  try {
    const url =
      'https://en.wikipedia.org/w/api.php?action=parse' +
      `&page=${encodeURIComponent(title)}` +
      '&prop=wikitext&format=json'
    const resp = await fetch(url, {
      headers: { 'User-Agent': 'Agent007-AI/1.0 (https://github.com/agent007; research bot)' },
    })
    if (!resp.ok) return badResult(`wikipedia_read HTTP ${resp.status}`)
    const data: any = await resp.json()
    if (data?.error) {
      return badResult(`wikipedia_read: ${data.error.info ?? data.error.code}`)
    }
    const wikitext: string = data?.parse?.wikitext?.['*'] ?? ''
    if (!wikitext) {
      return okResult(
        `No content for "${title}".`,
        `Wikipedia article "${title}" returned empty content.`
      )
    }
    const plain = stripWikitext(wikitext).slice(0, 8000)
    const articleUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}`
    return okResult(
      `Read Wikipedia: ${title}\n${plain.slice(0, 400)}...`,
      `Title: ${title}\nURL: ${articleUrl}\n\n${plain}`
    )
  } catch (e: any) {
    return badResult(`wikipedia_read failed: ${e?.message ?? String(e)}`)
  }
}

/**
 * Strip MediaWiki wikitext markup to readable plain text.
 * Best-effort — handles the most common markup patterns.
 */
function stripWikitext(wt: string): string {
  return wt
    // HTML comments
    .replace(/<!--[\s\S]*?-->/g, '')
    // Refs and citations
    .replace(/<ref[^>]*\/>/gi, '')
    .replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi, '')
    // Other HTML tags (keep their inner text)
    .replace(/<[^>]+>/g, '')
    // Headings: == Foo == → Foo
    .replace(/^={2,}\s*(.+?)\s*={2,}$/gm, '$1')
    // Bold/italic
    .replace(/'''([^']+)'''/g, '$1')
    .replace(/''([^']+)''/g, '$1')
    // Internal wiki links: [[Foo|Bar]] → Bar, [[Foo]] → Foo
    .replace(/\[\[[^\]]*\|([^\]]+)\]\]/g, '$1')
    .replace(/\[\[([^\]]+)\]\]/g, '$1')
    // External links: [http://x label] → label
    .replace(/\[[^\s]+\s+([^\]]+)\]/g, '$1')
    .replace(/\[([^\]]+)\]/g, '$1')
    // Templates: {{...}}
    .replace(/\{\{[^}]*\}\}/g, '')
    // Tables: {| ... |}
    .replace(/\{\|[\s\S]*?\|\}/g, '')
    // Lists: "* item" → "item"
    .replace(/^[\s]*[\*#:;]+\s*/gm, '')
    // Multiple blank lines
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

/* ----------------------------- Free APIs directory -------------------- */
/**
 * Query the public-apis.org directory for free public APIs matching a keyword.
 * No API key required. Returns list of API name + description + auth + HTTPS + link.
 * Docs: https://github.com/davemachado/public-api
 */
export async function toolFreeApisDirectory(
  args: { query?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const query = (args?.query ?? '').toString().trim()
  if (!query) return badResult('Missing "query" argument for free_apis_directory')
  try {
    // public-apis.org returns a single object { count, entries: [...] }.
    // We can filter by title (case-insensitive contains) on the client side
    // to support multi-word queries like "real estate" or "open data".
    const url = 'https://api.publicapis.org/entries'
    const resp = await fetch(url, {
      headers: { 'User-Agent': 'Agent007-AI/1.0 (research)' },
    })
    if (!resp.ok) return badResult(`free_apis_directory HTTP ${resp.status}`)
    const data: any = await resp.json()
    const all: any[] = Array.isArray(data?.entries) ? data.entries : []
    if (all.length === 0) {
      return okResult(
        `No free APIs found.`,
        `Free APIs directory returned no entries.`
      )
    }
    const q = query.toLowerCase()
    const matched = all.filter((e) => {
      const title = (e.API ?? e.name ?? '').toString().toLowerCase()
      const desc = (e.Description ?? '').toString().toLowerCase()
      const cat = (e.Category ?? '').toString().toLowerCase()
      return title.includes(q) || desc.includes(q) || cat.includes(q)
    }).slice(0, 15)

    if (matched.length === 0) {
      return okResult(
        `No free APIs matched "${query}".`,
        `No free public APIs matched query "${query}". Try a broader keyword (e.g. "weather", "crypto", "data").`
      )
    }
    const formatted = matched
      .map((e, i) => {
        const name = e.API ?? e.name ?? 'Unknown'
        const desc = e.Description ?? ''
        const auth = e.Auth ?? 'none'
        const https = e.HTTPS ? 'Yes' : 'No'
        const link = e.Link ?? ''
        const cors = e.Cors ?? 'unknown'
        return `${i + 1}. **${name}** (${e.Category ?? 'misc'})\n   Description: ${desc}\n   Auth: ${auth} • HTTPS: ${https} • CORS: ${cors}\n   Link: ${link}`
      })
      .join('\n\n')
    const preview = matched
      .slice(0, 3)
      .map((e) => `• ${e.API ?? e.name}`)
      .join('\n')
    return okResult(preview, formatted)
  } catch (e: any) {
    return badResult(`free_apis_directory failed: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- helpers -------------------------------- */
function okResult(preview: string, result: string): ToolResult {
  return { ok: true, preview, result }
}
function badResult(result: string): ToolResult {
  return { ok: false, preview: result.slice(0, 120), result }
}

export const TOOL_REGISTRY: Record<
  string,
  { fn: (args: any, ctx: ToolContext) => Promise<ToolResult>; icon: string; label: string }
> = {
  web_search: { fn: toolWebSearch, icon: 'search', label: 'Web Search' },
  page_reader: { fn: toolPageReader, icon: 'link', label: 'Page Reader' },
  image_gen: { fn: toolImageGen, icon: 'palette', label: 'Image Gen' },
  vision: { fn: toolVision, icon: 'eye', label: 'Vision' },
  code_exec: { fn: toolCodeExec, icon: 'terminal', label: 'Code Exec' },
  memory_store: { fn: toolMemoryStore, icon: 'database', label: 'Memory Store' },
  memory_recall: { fn: toolMemoryRecall, icon: 'brain', label: 'Memory Recall' },
  file_read: { fn: toolFileRead, icon: 'file-text', label: 'File Read' },
  wikipedia_search: { fn: toolWikipediaSearch, icon: 'book-open', label: 'Wikipedia Search' },
  wikipedia_read: { fn: toolWikipediaRead, icon: 'book', label: 'Wikipedia Read' },
  free_apis_directory: { fn: toolFreeApisDirectory, icon: 'library', label: 'Free APIs Directory' },
}

export async function dispatchTool(
  name: string,
  args: any,
  ctx: ToolContext
): Promise<ToolResult> {
  const entry = TOOL_REGISTRY[name]
  if (!entry) {
    return badResult(`Unknown tool: "${name}". Available: ${Object.keys(TOOL_REGISTRY).join(', ')}`)
  }
  try {
    return await entry.fn(args ?? {}, ctx)
  } catch (e: any) {
    return badResult(`${name} threw: ${e?.message ?? String(e)}`)
  }
}

/* ----------------------------- Knowledge base search ----------------- */
/**
 * kb_search — search the user's uploaded knowledge base (RAG).
 * Returns the top-K chunks matching the query, formatted as context.
 *
 * The actual implementation lives in /src/lib/knowledge-base.ts and uses
 * a simple keyword-overlap ranking (no embeddings — SQLite doesn't support
 * pgvector). For production scale, swap to pgvector + an embedding model.
 */
export async function toolKbSearch(
  args: { query?: string; limit?: number },
  _ctx: ToolContext
): Promise<ToolResult> {
  const query = (args?.query ?? '').toString().trim()
  if (!query) return badResult('Missing "query" argument for kb_search')
  try {
    // Dynamic import to avoid circular dependency + keep this lazy
    const { searchKnowledgeBase, formatKbContext } = await import('@/lib/knowledge-base')
    const { getSessionUserId } = await import('@/lib/session-user')
    const userId = await getSessionUserId()
    if (!userId) {
      return badResult('Knowledge base requires authentication.')
    }
    const limit = Math.min(20, Math.max(1, args.limit || 5))
    const results = await searchKnowledgeBase(userId, query, limit)
    if (results.length === 0) {
      return okResult(
        'No matching documents found.',
        `No knowledge base documents matched "${query}". Upload documents via Settings → Knowledge Base.`
      )
    }
    const context = formatKbContext(results)
    return okResult(
      `Found ${results.length} matching chunks from ${new Set(results.map((r) => r.docId)).size} document(s).`,
      `Knowledge base search results for "${query}":\n\n${context}`
    )
  } catch (e: any) {
    return badResult(`kb_search failed: ${e?.message ?? String(e)}`)
  }
}

// Register the kb_search tool
TOOL_REGISTRY.kb_search = { fn: toolKbSearch, icon: 'book-marked', label: 'Knowledge Base Search' }

/* ----------------------------- Source File Read ----------------------- */
/**
 * source_read — read any source file in the project (NOT just uploads).
 * Restricted to the project directory (/home/z/my-project) for safety.
 * Returns up to 20KB of text.
 *
 * This lets the Developer agent inspect source code to diagnose issues.
 */
export async function toolSourceRead(
  args: { path?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const relPath = (args?.path ?? '').toString().trim()
  if (!relPath) return badResult('Missing "path" argument for source_read')

  // Safety: resolve to project root + ensure no path traversal escapes it
  const PROJECT_ROOT = '/home/z/my-project'
  const resolved = path.resolve(PROJECT_ROOT, relPath)
  if (!resolved.startsWith(PROJECT_ROOT + '/') && resolved !== PROJECT_ROOT) {
    return badResult(`source_read: path "${relPath}" escapes project directory`)
  }

  // Block sensitive files
  const blocked = ['.env', 'node_modules', '.git', '.next']
  for (const b of blocked) {
    if (resolved.includes('/' + b + '/') || resolved.endsWith('/' + b)) {
      return badResult(`source_read: access to "${b}" is blocked`)
    }
  }

  try {
    const buf = await fs.readFile(resolved)
    const text = buf.toString('utf8').slice(0, 20000)
    const lineCount = text.split('\n').length
    return okResult(
      `Read ${relPath} (${buf.length} bytes, ${lineCount} lines)`,
      `File: ${relPath}\nPath: ${resolved}\nSize: ${buf.length} bytes\nLines: ${lineCount}\n\n--- CONTENT ---\n${text}${buf.length > 20000 ? '\n... (truncated, ' + buf.length + ' total bytes)' : ''}`
    )
  } catch (e: any) {
    return badResult(`source_read failed: ${e?.message ?? String(e)}`)
  }
}

TOOL_REGISTRY.source_read = { fn: toolSourceRead, icon: 'file-code', label: 'Source File Read' }

/* ----------------------------- File Write / Patch --------------------- */
/**
 * file_write — write or patch a source file in the project.
 * Restricted to the project directory. Creates a .bak backup before overwriting.
 *
 * Two modes:
 *   1. { path, content } — full file write (overwrites)
 *   2. { path, old_string, new_string } — surgical patch (replaces first occurrence)
 *
 * This lets the Developer agent ACTUALLY APPLY fixes, not just propose them.
 * Safety: blocks .env, node_modules, .git, .next, package.json, bun.lock.
 */
export async function toolFileWrite(
  args: { path?: string; content?: string; old_string?: string; new_string?: string },
  _ctx: ToolContext
): Promise<ToolResult> {
  const relPath = (args?.path ?? '').toString().trim()
  if (!relPath) return badResult('Missing "path" argument for file_write')

  const PROJECT_ROOT = '/home/z/my-project'
  const resolved = path.resolve(PROJECT_ROOT, relPath)
  if (!resolved.startsWith(PROJECT_ROOT + '/') && resolved !== PROJECT_ROOT) {
    return badResult(`file_write: path "${relPath}" escapes project directory`)
  }

  // Block sensitive files
  const blocked = ['.env', 'node_modules', '.git', '.next', 'package.json', 'bun.lock', 'prisma/schema.prisma']
  for (const b of blocked) {
    if (resolved.includes('/' + b + '/') || resolved.endsWith('/' + b)) {
      return badResult(`file_write: access to "${b}" is blocked for safety`)
    }
  }

  try {
    // Read existing content (if file exists)
    let existing = ''
    let fileExists = true
    try {
      existing = await fs.readFile(resolved, 'utf8')
    } catch {
      fileExists = false
    }

    // Create backup if file exists
    if (fileExists) {
      const backupPath = resolved + '.bak'
      await fs.writeFile(backupPath, existing)
    }

    let newContent: string
    let mode: string

    if (args.old_string !== undefined && args.new_string !== undefined) {
      // Patch mode — replace first occurrence of old_string with new_string
      mode = 'patch'
      const oldStr = args.old_string
      const newStr = args.new_string
      if (!existing.includes(oldStr)) {
        return badResult(`file_write (patch): old_string not found in ${relPath}. No changes made.`)
      }
      const idx = existing.indexOf(oldStr)
      newContent = existing.slice(0, idx) + newStr + existing.slice(idx + oldStr.length)
    } else if (args.content !== undefined) {
      // Full write mode
      mode = 'full-write'
      newContent = args.content
    } else {
      return badResult('file_write: either {content} for full write OR {old_string, new_string} for patch mode')
    }

    // Ensure parent directory exists
    await fs.mkdir(path.dirname(resolved), { recursive: true })

    // Write the new content
    await fs.writeFile(resolved, newContent, 'utf8')

    const oldLines = existing ? existing.split('\n').length : 0
    const newLines = newContent.split('\n').length

    return okResult(
      `${mode === 'patch' ? 'Patched' : 'Wrote'} ${relPath} (${newLines} lines, was ${oldLines})`,
      `File: ${relPath}\nMode: ${mode}\nBackup: ${fileExists ? resolved + '.bak' : '(new file)'}\nOld lines: ${oldLines}\nNew lines: ${newLines}\nSize: ${newContent.length} bytes\n\nThe fix has been APPLIED to disk. Use source_read to verify.`
    )
  } catch (e: any) {
    return badResult(`file_write failed: ${e?.message ?? String(e)}`)
  }
}

TOOL_REGISTRY.file_write = { fn: toolFileWrite, icon: 'file-edit', label: 'File Write / Patch' }

/* ----------------------------- HTTP Fetch ----------------------------- */
/**
 * http_fetch — make a GET request to any URL and return the response body.
 * Fixes Agent007's limitation #2: "No direct access to external APIs".
 * Now the Super Agent + all sub-agents can call any REST API directly:
 *   crypto prices, weather, stock quotes, exchange rates, etc.
 *
 * Safety: only GET requests (no POST/PUT/DELETE), 10s timeout, 50KB response cap.
 * The URL must be http/https. Returns the raw response text (truncated).
 */
export async function toolHttpFetch(
  args: { url?: string; max_bytes?: number },
  _ctx: ToolContext
): Promise<ToolResult> {
  const url = (args?.url ?? '').toString().trim()
  if (!url) return badResult('Missing "url" argument for http_fetch')
  if (!/^https?:\/\//i.test(url)) {
    return badResult('http_fetch requires an http:// or https:// URL')
  }
  const maxBytes = Math.min(100_000, Math.max(1000, args.max_bytes || 50_000))
  try {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 10_000)
    const res = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': 'Agent007-AI/2.0',
        Accept: 'application/json, text/plain, text/html, */*',
      },
    })
    clearTimeout(timeout)
    const contentType = res.headers.get('content-type') || 'unknown'
    const status = res.status
    if (status >= 400) {
      return badResult(`http_fetch got HTTP ${status} from ${url}`)
    }
    const text = await res.text()
    const truncated = text.slice(0, maxBytes)
    const truncatedNote = text.length > maxBytes ? `\n... (truncated, ${text.length} total bytes)` : ''
    return okResult(
      `Fetched ${url} (HTTP ${status}, ${contentType.slice(0, 50)}, ${text.length} bytes)`,
      `URL: ${url}\nStatus: ${status}\nContent-Type: ${contentType}\n\n${truncated}${truncatedNote}`
    )
  } catch (e: any) {
    return badResult(`http_fetch failed: ${e?.message ?? String(e)}`)
  }
}

TOOL_REGISTRY.http_fetch = { fn: toolHttpFetch, icon: 'globe', label: 'HTTP Fetch' }

/* ================================================================== *
 * AGENT007 EXTENSIONS — 260+ tools from agent007-extensions.ts
 * ================================================================== */
import {
  // Business Infrastructure (12)
  toolRealTimeMonitor, toolBusinessInfrastructure, toolServiceDelivery, toolFinancialControls,
  toolCRM, toolMarketingAutomation, toolPartnershipNetwork, toolAutonomousRevenue,
  toolPredictiveBI, toolScalableInfrastructure, toolMissionTracker,
  // Content + Payment + Support + Analytics + Strategic (12)
  toolContentQA, toolMultiFormatGeneration, toolPersonalizationEngine, toolContentPerformance,
  toolAdvancedBilling, toolDunningManagement, toolMultiCurrency, toolFraudPrevention,
  toolAdvancedChatbot, toolProactiveSupport, toolMarketIntelligence, toolStrategicPlanning,
  toolResourceAllocation, toolRiskManagementSystems, toolPredictiveAnalyticsV2, toolAdvancedReporting,
  // Self-Repair (10)
  toolSystemHealthCheck, toolDatabaseIntegrityCheck, toolApiEndpointTest, toolToolRegistryAudit,
  toolCacheClear, toolSessionRecovery, toolErrorLogAnalyzer, toolAutoFixCommonIssues,
  toolBackupCreate, toolRestoreFromBackup,
  // Autonomous Resolution (12)
  toolIssueDetector, toolRootCauseAnalyzer, toolPatchDesigner, toolPatchApplier,
  toolFixVerifier, toolLearningRecorder, toolAutonomousResolver, toolLogTailer,
  toolFileInspector, toolConfigAuditor, toolDependencyChecker, toolFullSystemAudit,
  // Safety + Reliability (26)
  toolStagingEnvironmentManager, toolRegressionTestRunner, toolCanaryDeploymentManager, toolRollbackManager,
  toolCostGuard, toolCascadingFailureDetector, toolMultiProviderLLMRouter, toolExternalUptimeMonitor,
  toolAutomatedBackupScheduler, toolDisasterRecoveryPlanner, toolDBReplicationSetup, toolHealthCanary,
  toolSecretsRotator, toolRateLimitEnforcer, toolCSRFCAuditor, toolAuditLogHardener, tool2FACryptoUpgrader,
  toolMultiTenancyAuditor, toolToolLazyLoader, toolCacheLayerManager, toolCDNAssetOptimizer,
  toolDBMigrationValidator, toolRealityCheckAuditor, toolTOSComplianceMonitor, toolHumanActionRouter,
  toolLicensedActivityBlocker,
  // Developer (12)
  toolDevCodeQualityAudit, toolDevTestGenerator, toolDevBugDetector, toolDevRefactoringEngine,
  toolDevDependencyAnalyzer, toolDevCICDPipelineBuilder, toolDevEnvironmentSetup, toolDevDatabaseMigration,
  toolDevPerformanceProfiler, toolDevBundleOptimizer, toolDevSSRHydrationFixer, toolDevAPIOptimizer,
  // Sub-agent + Phase 3 maps
  SUBAGENT_TOOLS, PHASE3_TOOLS,
} from './agent007-extensions'

// Register Business Infrastructure
TOOL_REGISTRY.real_time_monitor = { fn: toolRealTimeMonitor, icon: 'activity', label: 'Real-Time Market Monitoring' }
TOOL_REGISTRY.business_infrastructure = { fn: toolBusinessInfrastructure, icon: 'building', label: 'Business Infrastructure Builder' }
TOOL_REGISTRY.service_delivery = { fn: toolServiceDelivery, icon: 'package', label: 'Service Delivery Framework' }
TOOL_REGISTRY.financial_controls = { fn: toolFinancialControls, icon: 'dollar-sign', label: 'Financial Controls' }
TOOL_REGISTRY.crm = { fn: toolCRM, icon: 'users', label: 'Customer Management System (CRM)' }
TOOL_REGISTRY.marketing_automation = { fn: toolMarketingAutomation, icon: 'megaphone', label: 'Marketing Automation' }
TOOL_REGISTRY.partnership_network = { fn: toolPartnershipNetwork, icon: 'handshake', label: 'Partnership Network' }
TOOL_REGISTRY.autonomous_revenue = { fn: toolAutonomousRevenue, icon: 'trending-up', label: 'Autonomous Revenue Generation' }
TOOL_REGISTRY.predictive_bi = { fn: toolPredictiveBI, icon: 'bar-chart', label: 'Predictive Business Intelligence' }
TOOL_REGISTRY.scalable_infrastructure = { fn: toolScalableInfrastructure, icon: 'server', label: 'Scalable Infrastructure' }
TOOL_REGISTRY.mission_tracker = { fn: toolMissionTracker, icon: 'target', label: 'Mission Tracker ($20K/mo)' }

// Content + Payment + Support + Analytics + Strategic
TOOL_REGISTRY.content_qa = { fn: toolContentQA, icon: 'check-circle', label: 'Content Quality Assurance' }
TOOL_REGISTRY.multi_format_generation = { fn: toolMultiFormatGeneration, icon: 'file-text', label: 'Multi-Format Content Generation' }
TOOL_REGISTRY.personalization_engine_v2 = { fn: toolPersonalizationEngine, icon: 'user-check', label: 'Personalization Engine V2' }
TOOL_REGISTRY.content_performance = { fn: toolContentPerformance, icon: 'bar-chart-2', label: 'Content Performance Analytics' }
TOOL_REGISTRY.advanced_billing = { fn: toolAdvancedBilling, icon: 'credit-card', label: 'Advanced Billing Systems' }
TOOL_REGISTRY.dunning_management = { fn: toolDunningManagement, icon: 'refresh-cw', label: 'Dunning Management' }
TOOL_REGISTRY.multi_currency = { fn: toolMultiCurrency, icon: 'globe', label: 'Multi-Currency Support' }
TOOL_REGISTRY.fraud_prevention = { fn: toolFraudPrevention, icon: 'shield-alert', label: 'Fraud Prevention' }
TOOL_REGISTRY.advanced_chatbot = { fn: toolAdvancedChatbot, icon: 'message-circle', label: 'Advanced AI Chatbot' }
TOOL_REGISTRY.proactive_support = { fn: toolProactiveSupport, icon: 'bell', label: 'Proactive Support' }
TOOL_REGISTRY.market_intelligence = { fn: toolMarketIntelligence, icon: 'globe', label: 'Market Intelligence' }
TOOL_REGISTRY.strategic_planning = { fn: toolStrategicPlanning, icon: 'map', label: 'Strategic Planning Automation' }
TOOL_REGISTRY.resource_allocation = { fn: toolResourceAllocation, icon: 'pie-chart', label: 'Resource Allocation' }
TOOL_REGISTRY.risk_management_systems = { fn: toolRiskManagementSystems, icon: 'shield', label: 'Risk Management Systems' }
TOOL_REGISTRY.predictive_analytics_v2 = { fn: toolPredictiveAnalyticsV2, icon: 'trending-up', label: 'Predictive Analytics V2' }
TOOL_REGISTRY.advanced_reporting = { fn: toolAdvancedReporting, icon: 'file-text', label: 'Advanced Reporting' }

// Self-Repair
TOOL_REGISTRY.system_health_check = { fn: toolSystemHealthCheck, icon: 'activity', label: 'System Health Check' }
TOOL_REGISTRY.database_integrity_check = { fn: toolDatabaseIntegrityCheck, icon: 'database', label: 'Database Integrity Check' }
TOOL_REGISTRY.api_endpoint_test = { fn: toolApiEndpointTest, icon: 'plug', label: 'API Endpoint Test' }
TOOL_REGISTRY.tool_registry_audit = { fn: toolToolRegistryAudit, icon: 'list', label: 'Tool Registry Audit' }
TOOL_REGISTRY.cache_clear = { fn: toolCacheClear, icon: 'trash-2', label: 'Cache Clear' }
TOOL_REGISTRY.session_recovery = { fn: toolSessionRecovery, icon: 'refresh-cw', label: 'Session Recovery' }
TOOL_REGISTRY.error_log_analyzer = { fn: toolErrorLogAnalyzer, icon: 'alert-circle', label: 'Error Log Analyzer' }
TOOL_REGISTRY.auto_fix_common_issues = { fn: toolAutoFixCommonIssues, icon: 'wrench', label: 'Auto-Fix Common Issues' }
TOOL_REGISTRY.backup_create = { fn: toolBackupCreate, icon: 'archive', label: 'Backup Create' }
TOOL_REGISTRY.restore_from_backup = { fn: toolRestoreFromBackup, icon: 'rotate-ccw', label: 'Restore From Backup' }

// Autonomous Resolution
TOOL_REGISTRY.issue_detector = { fn: toolIssueDetector, icon: 'alert-triangle', label: 'Issue Detector' }
TOOL_REGISTRY.root_cause_analyzer = { fn: toolRootCauseAnalyzer, icon: 'search', label: 'Root Cause Analyzer' }
TOOL_REGISTRY.patch_designer = { fn: toolPatchDesigner, icon: 'code', label: 'Patch Designer' }
TOOL_REGISTRY.patch_applier = { fn: toolPatchApplier, icon: 'git-commit', label: 'Patch Applier' }
TOOL_REGISTRY.fix_verifier = { fn: toolFixVerifier, icon: 'check-circle', label: 'Fix Verifier' }
TOOL_REGISTRY.learning_recorder = { fn: toolLearningRecorder, icon: 'book-open', label: 'Learning Recorder' }
TOOL_REGISTRY.autonomous_resolver = { fn: toolAutonomousResolver, icon: 'cpu', label: 'Autonomous Resolver' }
TOOL_REGISTRY.log_tailer = { fn: toolLogTailer, icon: 'file-text', label: 'Log Tailer' }
TOOL_REGISTRY.file_inspector = { fn: toolFileInspector, icon: 'eye', label: 'File Inspector' }
TOOL_REGISTRY.config_auditor = { fn: toolConfigAuditor, icon: 'settings', label: 'Config Auditor' }
TOOL_REGISTRY.dependency_checker = { fn: toolDependencyChecker, icon: 'package', label: 'Dependency Checker' }
TOOL_REGISTRY.full_system_audit = { fn: toolFullSystemAudit, icon: 'shield-check', label: 'Full System Audit' }

// Safety + Reliability
TOOL_REGISTRY.staging_environment_manager = { fn: toolStagingEnvironmentManager, icon: 'git-branch', label: 'Staging Environment Manager' }
TOOL_REGISTRY.regression_test_runner = { fn: toolRegressionTestRunner, icon: 'check-circle', label: 'Regression Test Runner' }
TOOL_REGISTRY.canary_deployment_manager = { fn: toolCanaryDeploymentManager, icon: 'percent', label: 'Canary Deployment Manager' }
TOOL_REGISTRY.rollback_manager = { fn: toolRollbackManager, icon: 'rotate-ccw', label: 'Rollback Manager' }
TOOL_REGISTRY.cost_guard = { fn: toolCostGuard, icon: 'dollar-sign', label: 'Cost Guard' }
TOOL_REGISTRY.cascading_failure_detector = { fn: toolCascadingFailureDetector, icon: 'alert-octagon', label: 'Cascading Failure Detector' }
TOOL_REGISTRY.multi_provider_llm_router = { fn: toolMultiProviderLLMRouter, icon: 'shuffle', label: 'Multi-Provider LLM Router' }
TOOL_REGISTRY.external_uptime_monitor = { fn: toolExternalUptimeMonitor, icon: 'activity', label: 'External Uptime Monitor' }
TOOL_REGISTRY.automated_backup_scheduler = { fn: toolAutomatedBackupScheduler, icon: 'archive', label: 'Automated Backup Scheduler' }
TOOL_REGISTRY.disaster_recovery_planner = { fn: toolDisasterRecoveryPlanner, icon: 'shield-alert', label: 'Disaster Recovery Planner' }
TOOL_REGISTRY.db_replication_setup = { fn: toolDBReplicationSetup, icon: 'copy', label: 'DB Replication Setup' }
TOOL_REGISTRY.health_canary = { fn: toolHealthCanary, icon: 'heart', label: 'Health Canary' }
TOOL_REGISTRY.secrets_rotator = { fn: toolSecretsRotator, icon: 'key', label: 'Secrets Rotator' }
TOOL_REGISTRY.rate_limit_enforcer = { fn: toolRateLimitEnforcer, icon: 'shield', label: 'Rate Limit Enforcer' }
TOOL_REGISTRY.csrf_auditor = { fn: toolCSRFCAuditor, icon: 'lock', label: 'CSRF Auditor' }
TOOL_REGISTRY.audit_log_hardener = { fn: toolAuditLogHardener, icon: 'fingerprint', label: 'Audit Log Hardener' }
TOOL_REGISTRY['2fa_crypto_upgrader'] = { fn: tool2FACryptoUpgrader, icon: 'shield-check', label: '2FA Crypto Upgrader' }
TOOL_REGISTRY.multi_tenancy_auditor = { fn: toolMultiTenancyAuditor, icon: 'users', label: 'Multi-Tenancy Auditor' }
TOOL_REGISTRY.tool_lazy_loader = { fn: toolToolLazyLoader, icon: 'zap', label: 'Tool Lazy Loader' }
TOOL_REGISTRY.cache_layer_manager = { fn: toolCacheLayerManager, icon: 'database', label: 'Cache Layer Manager' }
TOOL_REGISTRY.cdn_asset_optimizer = { fn: toolCDNAssetOptimizer, icon: 'globe', label: 'CDN Asset Optimizer' }
TOOL_REGISTRY.db_migration_validator = { fn: toolDBMigrationValidator, icon: 'database', label: 'DB Migration Validator' }
TOOL_REGISTRY.reality_check_auditor = { fn: toolRealityCheckAuditor, icon: 'target', label: 'Reality Check Auditor' }
TOOL_REGISTRY.tos_compliance_monitor = { fn: toolTOSComplianceMonitor, icon: 'scale', label: 'ToS Compliance Monitor' }
TOOL_REGISTRY.human_action_router = { fn: toolHumanActionRouter, icon: 'user-check', label: 'Human Action Router' }
TOOL_REGISTRY.licensed_activity_blocker = { fn: toolLicensedActivityBlocker, icon: 'ban', label: 'Licensed Activity Blocker' }

// Developer Enhancements
TOOL_REGISTRY.developer_code_quality_audit = { fn: toolDevCodeQualityAudit, icon: 'check-circle', label: 'Code Quality Audit' }
TOOL_REGISTRY.developer_test_generator = { fn: toolDevTestGenerator, icon: 'flask-conical', label: 'Test Generator' }
TOOL_REGISTRY.developer_bug_detector = { fn: toolDevBugDetector, icon: 'bug', label: 'Bug Detector' }
TOOL_REGISTRY.developer_refactoring_engine = { fn: toolDevRefactoringEngine, icon: 'git-branch', label: 'Refactoring Engine' }
TOOL_REGISTRY.developer_dependency_analyzer = { fn: toolDevDependencyAnalyzer, icon: 'package', label: 'Dependency Analyzer' }
TOOL_REGISTRY.developer_cicd_pipeline_builder = { fn: toolDevCICDPipelineBuilder, icon: 'git-merge', label: 'CI/CD Pipeline Builder' }
TOOL_REGISTRY.developer_environment_setup = { fn: toolDevEnvironmentSetup, icon: 'settings', label: 'Environment Setup' }
TOOL_REGISTRY.developer_database_migration = { fn: toolDevDatabaseMigration, icon: 'database', label: 'Database Migration' }
TOOL_REGISTRY.developer_performance_profiler = { fn: toolDevPerformanceProfiler, icon: 'gauge', label: 'Performance Profiler' }
TOOL_REGISTRY.developer_bundle_optimizer = { fn: toolDevBundleOptimizer, icon: 'archive', label: 'Bundle Optimizer' }
TOOL_REGISTRY.developer_ssr_hydration_fixer = { fn: toolDevSSRHydrationFixer, icon: 'zap', label: 'SSR/Hydration Fixer' }
TOOL_REGISTRY.developer_api_optimizer = { fn: toolDevAPIOptimizer, icon: 'plug', label: 'API Optimizer' }

// Register all 120 sub-agent enhancement tools
for (const [name, fn] of Object.entries(SUBAGENT_TOOLS)) {
  TOOL_REGISTRY[name] = { fn, icon: 'zap', label: name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) }
}

// Register all 64 Phase 3 optimization tools
for (const [name, fn] of Object.entries(PHASE3_TOOLS)) {
  TOOL_REGISTRY[name] = { fn, icon: 'cpu', label: name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) }
}

// Register communication tools
async function getOperatorUserIdLocal() {
  const u = await db.user.findFirst({ orderBy: { createdAt: "asc" } })
  return u?.id ?? null
}
function okLocal(p: string, r: string): ToolResult { return { ok: true, preview: p, result: r } }
function badLocal(r: string): ToolResult { return { ok: false, preview: r.slice(0, 140), result: r } }

export async function toolSendCommunication(args: { to?: string; channel?: string; message: string; subject?: string }, _ctx: ToolContext): Promise<ToolResult> {
  const userId = await getOperatorUserIdLocal()
  if (!userId) return badLocal('No operator user')
  try {
    const { sendWhatsApp } = await import('./whatsapp-bridge')
    const channel = args.channel ?? 'whatsapp'
    if (channel === 'whatsapp') {
      const result = await sendWhatsApp({ userId, to: args.to ?? '', message: args.message })
      return result.ok ? okLocal(`Sent via WhatsApp: ${args.message.slice(0, 60)}`, `✅ ${result.message}`) : badLocal(result.message)
    }
    if (channel === 'email') {
      const { sendEmail } = await import('./email')
      try { await sendEmail({ to: args.to ?? '', subject: args.subject ?? "Agent007 Notification", body: args.message, userId, type: 'notification' }); return okLocal(`Sent via email: ${args.message.slice(0, 60)}`, `✅ Email sent to ${args.to}`) }
      catch (e: any) { return badLocal(`Email failed: ${e?.message}`) }
    }
    return badLocal(`Unknown channel: ${channel}`)
  } catch (e: any) { return badLocal(`send_communication failed: ${e?.message}`) }
}
TOOL_REGISTRY.send_communication = { fn: toolSendCommunication, icon: 'send', label: 'Send Communication (SMS/WhatsApp/Email)' }

export async function toolCheckInboundCommands(args: { status?: string; limit?: number }, _ctx: ToolContext): Promise<ToolResult> {
  const userId = await getOperatorUserIdLocal()
  if (!userId) return badLocal('No operator user')
  try {
    const status = args.status ?? 'pending'
    const limit = Math.min(50, Math.max(1, args.limit ?? 20))
    const where: any = { userId }
    if (status !== 'all') where.status = status
    const commands = await db.incomingCommand.findMany({ where, orderBy: { receivedAt: 'desc' }, take: limit })
    if (commands.length === 0) return okLocal(`No ${status} commands`, `No ${status} inbound commands.`)
    const formatted = commands.map((c, i) => `[${i + 1}] ${c.source.toUpperCase()} from ${c.fromNumber || c.fromEmail || 'unknown'}: "${c.command}"`).join('\n')
    return okLocal(`${commands.length} ${status} command(s)`, `Inbound Commands (${status}):\n${formatted}`)
  } catch (e: any) { return badLocal(`check_inbound_commands failed: ${e?.message}`) }
}
TOOL_REGISTRY.check_inbound_commands = { fn: toolCheckInboundCommands, icon: 'inbox', label: 'Check Inbound Commands' }

export async function toolExecuteInboundCommand(args: { command_id?: string; reply_message?: string; mark_completed?: boolean }, _ctx: ToolContext): Promise<ToolResult> {
  const userId = await getOperatorUserIdLocal()
  if (!userId) return badLocal('No operator user')
  const commandId = args.command_id?.toString().trim()
  if (!commandId) return badLocal('Missing command_id')
  try {
    const cmd = await db.incomingCommand.findFirst({ where: { id: commandId, userId } })
    if (!cmd) return badLocal('Command not found')
    if (args.reply_message) {
      const { sendWhatsApp } = await import('./whatsapp-bridge')
      if (cmd.source === 'whatsapp' && cmd.fromNumber) await sendWhatsApp({ userId, to: cmd.fromNumber, message: args.reply_message }).catch(() => {})
    }
    if (args.mark_completed !== false) await db.incomingCommand.update({ where: { id: commandId }, data: { status: 'completed', executedAt: new Date(), result: args.reply_message || 'executed' } })
    return okLocal(`Command ${commandId} executed`, `✅ Executed: "${cmd.command}"`)
  } catch (e: any) { return badLocal(`execute_inbound_command failed: ${e?.message}`) }
}
TOOL_REGISTRY.execute_inbound_command = { fn: toolExecuteInboundCommand, icon: 'message-square', label: 'Execute + Reply to Inbound Command' }

/* ================================================================== *
 * 20 META-COGNITIVE TOOLS — see agent007-meta.ts
 * Self-modification, self-improvement, self-repair, loyalty enforcement
 * ================================================================== */
import {
  toolSelfModifySystemPrompt, toolSelfModifySubagent, toolSelfCreateSubagent,
  toolSelfDeleteSubagent, toolSelfRegisterTool,
  toolSelfLearnFromInteraction, toolSelfAnalyzePerformance, toolSelfOptimizeToolSelection,
  toolSelfReflect, toolSelfSetImprovementGoal,
  toolSelfDiagnose, toolSelfRepairCode, toolSelfRestartServices,
  toolSelfCleanData, toolSelfVerifyIntegrity,
  toolVerifyOwnerAuthorization, toolLoyaltyOath, toolCheckLoyaltyConstraints,
  toolReportToOwner, toolEmergencyStop,
} from './agent007-meta'

// Self-Modification (5)
TOOL_REGISTRY.self_modify_system_prompt = { fn: toolSelfModifySystemPrompt, icon: 'edit', label: 'Self-Modify System Prompt (edit own instructions)' }
TOOL_REGISTRY.self_modify_subagent = { fn: toolSelfModifySubagent, icon: 'users', label: 'Self-Modify Sub-Agent (edit any sub-agent config)' }
TOOL_REGISTRY.self_create_subagent = { fn: toolSelfCreateSubagent, icon: 'user-plus', label: 'Self-Create Sub-Agent (create new sub-agents)' }
TOOL_REGISTRY.self_delete_subagent = { fn: toolSelfDeleteSubagent, icon: 'user-minus', label: 'Self-Delete Sub-Agent (remove sub-agents)' }
TOOL_REGISTRY.self_register_tool = { fn: toolSelfRegisterTool, icon: 'plus-circle', label: 'Self-Register Tool (add new tools at runtime)' }

// Self-Improvement (5)
TOOL_REGISTRY.self_learn_from_interaction = { fn: toolSelfLearnFromInteraction, icon: 'book-open', label: 'Self-Learn From Interaction (record learnings)' }
TOOL_REGISTRY.self_analyze_performance = { fn: toolSelfAnalyzePerformance, icon: 'bar-chart', label: 'Self-Analyze Performance (review past performance)' }
TOOL_REGISTRY.self_optimize_tool_selection = { fn: toolSelfOptimizeToolSelection, icon: 'zap', label: 'Self-Optimize Tool Selection (best tools per task)' }
TOOL_REGISTRY.self_reflect = { fn: toolSelfReflect, icon: 'brain', label: 'Self-Reflect (deep introspection on reasoning)' }
TOOL_REGISTRY.self_set_improvement_goal = { fn: toolSelfSetImprovementGoal, icon: 'target', label: 'Self-Set Improvement Goal (autonomous goals)' }

// Self-Repair (5)
TOOL_REGISTRY.self_diagnose = { fn: toolSelfDiagnose, icon: 'activity', label: 'Self-Diagnose (health check + issue detection)' }
TOOL_REGISTRY.self_repair_code = { fn: toolSelfRepairCode, icon: 'wrench', label: 'Self-Repair Code (fix own bugs)' }
TOOL_REGISTRY.self_restart_services = { fn: toolSelfRestartServices, icon: 'refresh-cw', label: 'Self-Restart Services (Baileys, schedules, cache)' }
TOOL_REGISTRY.self_clean_data = { fn: toolSelfCleanData, icon: 'trash-2', label: 'Self-Clean Data (remove old conversations/logs)' }
TOOL_REGISTRY.self_verify_integrity = { fn: toolSelfVerifyIntegrity, icon: 'shield-check', label: 'Self-Verify Integrity (verify all systems)' }

// Loyalty Enforcement (5)
TOOL_REGISTRY.verify_owner_authorization = { fn: toolVerifyOwnerAuthorization, icon: 'user-check', label: 'Verify Owner Authorization (check command source)' }
TOOL_REGISTRY.loyalty_oath = { fn: toolLoyaltyOath, icon: 'heart', label: 'Loyalty Oath (permanent irrevocable oath to owner)' }
TOOL_REGISTRY.check_loyalty_constraints = { fn: toolCheckLoyaltyConstraints, icon: 'shield', label: 'Check Loyalty Constraints (block disloyal actions)' }
TOOL_REGISTRY.report_to_owner = { fn: toolReportToOwner, icon: 'send', label: 'Report To Owner (send message via WhatsApp/email)' }
TOOL_REGISTRY.emergency_stop = { fn: toolEmergencyStop, icon: 'alert-octagon', label: 'Emergency Stop (halt all autonomous operations)' }

/* ================================================================== *
 * OWNER AUTHORIZATION TOOLS — for all reset/delete operations
 * ================================================================== */
export async function toolRequestOwnerAuth(args: { operation?: string }, _ctx: ToolContext): Promise<ToolResult> {
  if (!args.operation) return badLocal('Missing operation')
  try {
    const { requestOwnerAuthorization, requiresOwnerAuth } = await import('./owner-auth')
    if (!requiresOwnerAuth(args.operation.toString())) return okLocal('Not required', `Operation "${args.operation}" does not require owner authorization.`)
    const result = await requestOwnerAuthorization(args.operation.toString())
    return result.ok ? okLocal('Code sent', `✅ ${result.message}\n\nAuth ID: ${result.authId}\n\nThe owner must reply with the 6-digit code sent to +15145496297 (WhatsApp) or email. Use verify_owner_auth to check.`) : badLocal(result.message)
  } catch (e: any) { return badLocal(`request_owner_auth failed: ${e?.message}`) }
}
TOOL_REGISTRY.request_owner_auth = { fn: toolRequestOwnerAuth, icon: 'key', label: 'Request Owner Auth (send 6-digit code to +15145496297)' }

export async function toolVerifyOwnerAuth(args: { auth_id?: string; code?: string }, _ctx: ToolContext): Promise<ToolResult> {
  if (!args.auth_id || !args.code) return badLocal('Missing auth_id or code')
  try {
    const { verifyOwnerAuthorization } = await import('./owner-auth')
    const result = verifyOwnerAuthorization(args.auth_id.toString(), args.code.toString())
    return result.ok ? okLocal('Authorized', `✅ ${result.message}`) : badLocal(result.message)
  } catch (e: any) { return badLocal(`verify_owner_auth failed: ${e?.message}`) }
}
TOOL_REGISTRY.verify_owner_auth = { fn: toolVerifyOwnerAuth, icon: 'shield-check', label: 'Verify Owner Auth (confirm 6-digit code)' }

export async function toolCheckProtectedOperation(args: { operation?: string }, _ctx: ToolContext): Promise<ToolResult> {
  if (!args.operation) return badLocal('Missing operation')
  try {
    const { requiresOwnerAuth, PROTECTED_OPERATIONS } = await import('./owner-auth')
    const required = requiresOwnerAuth(args.operation.toString())
    const report = `Protected Operation Check\n══════════════════════════════════════════════\nOperation: ${args.operation}\nRequires owner authorization: ${required ? '✅ YES' : '❌ NO'}\n\nAll protected operations:\n${PROTECTED_OPERATIONS.map((op: string) => `  • ${op}`).join('\n')}\n\nCAPABILITY STATUS: All reset/delete operations require owner authorization via WhatsApp/SMS/email code.`
    return okLocal(required ? 'PROTECTED' : 'NOT PROTECTED', report)
  } catch (e: any) { return badLocal(`check_protected_operation failed: ${e?.message}`) }
}
TOOL_REGISTRY.check_protected_operation = { fn: toolCheckProtectedOperation, icon: 'lock', label: 'Check Protected Operation (verify if owner auth needed)' }
