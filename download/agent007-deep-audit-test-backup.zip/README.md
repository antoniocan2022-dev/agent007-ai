# Agent007 AI — Owner Backup

Generated: 2026-07-16T22:48:03.508Z
Label: deep-audit-test-88

## Contents

1. agent007-backup-2026-07-16T22-48-02-885Z-deep-audit-test-88.json — full structured backup
   - All 33 DB tables (or empty if DB unavailable)
   - All 84 permanent upgrades
   - Capabilities snapshot
   - Config metadata

2. Source files (local dev only — Vercel doesn't bundle them):
   - src/lib/agent.ts
   - src/lib/orchestrator.ts
   - src/lib/tools.ts
   - src/lib/subagents.ts
   - src/middleware.ts
   - src/app/api/owner-backup/route.ts
   - vercel.json
   - prisma/schema.prisma
   - package.json
   - + more

## Auth

This backup was downloaded via /api/owner-backup?token=<OWNER_BACKUP_TOKEN>
Only the owner with the correct token can download backups.

## Stats

- Database tables: 33
- Total rows: 1326
- Upgrades: 84
- JSON size: 2.91 MB