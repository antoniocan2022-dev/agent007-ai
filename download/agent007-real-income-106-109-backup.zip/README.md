# Agent007 AI — Owner Backup

Generated: 2026-07-21T21:02:10.516Z
Label: real-income-106-109

## Contents

1. agent007-backup-2026-07-21T21-02-09-418Z-real-income-106-109.json — full structured backup
   - All 33 DB tables (or empty if DB unavailable)
   - All 98 permanent upgrades
   - Capabilities snapshot
   - Config metadata

2. Source files (local dev only — Vercel doesn't bundle them):
   - src/lib/agent.ts
   - src/lib/orchestrator.ts
   - src/lib/tools.ts
   - src/lib/subagents.ts
   - src/middleware.ts
   - src/app/api/owner-backup/route.ts
   - vercel.json
   - prisma/schema.prisma
   - package.json
   - + more

## Auth

This backup was downloaded via /api/owner-backup?token=<OWNER_BACKUP_TOKEN>
Only the owner with the correct token can download backups.

## Stats

- Database tables: 33
- Total rows: 3624
- Upgrades: 98
- JSON size: 8.18 MB