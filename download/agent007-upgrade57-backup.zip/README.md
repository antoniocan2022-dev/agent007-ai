# Agent007 AI — Upgrade #57 Full Backup

Generated: 2026-07-12T13:49:30.336Z
Git commit: 8844cef39d31c4e76b8d3e0ab1d67b5e7a361d8f

## What is in this backup

This backup captures the complete state of Upgrade #57 — repurposing two legacy
test agents into permanent scheduled monitors:

1. TESTFAST2 -> QA Monitor (id: testfast2)
   - Internal health checks at 4 depths (1h / 6h / 12h / 24h)
   - Vercel Cron: 0 * * * * (hourly at minute 0, UTC)
   - Tier auto-picked by UTC hour: 09->T4, 21->T3, 03/15->T2, else->T1
   - Endpoint: GET /api/monitor/qa

2. FASTTEST3 -> External Monitor (id: fasttest3)
   - External uptime monitoring every 30 min
   - Vercel Cron: 0,30 * * * * (every 30 min, UTC)
   - Probes 10 external endpoints in parallel batches of 5
   - Endpoint: GET /api/monitor/external

## Owner alerting

Both monitors auto-email antonio.can2022@hotmail.com via Resend on ANY failure.
Email subject includes severity (CRITICAL / HIGH / MEDIUM / LOW).
NotificationLog + Memory rows are created for every alert.

## Permanent locking

The two agents are in NEVER_DISABLE_IDS — they CANNOT be:
  - Deleted (DELETE -> 403 with permanent:true)
  - Disabled (PUT {enabled:false} -> 403 with permanent:true)
  - Have systemPrompt / allowedTools modified (PUT -> 403 with permanent:true)

To modify them, edit src/lib/subagents.ts and redeploy.

## Super agent integration

Both monitors are BUILTIN agents in SUBAGENTS with FULL_ACCESS to all tools.
The super agent (Agent007) can dispatch them via:
  <dispatch_subagent id="testfast2">
  <dispatch_subagent id="fasttest3">

Reports are stored in the Memory table with categories:
  - qa_health_report (every QA run)
  - external_uptime_report (every external run)
  - qa_alert (on failure)
  - external_uptime_alert (on failure)

## Files in this ZIP

- agent007-upgrade57-backup.json — full structured backup
- src/lib/monitor-agents.ts — monitor engine
- src/app/api/monitor/qa/route.ts — QA endpoint (Vercel Cron)
- src/app/api/monitor/external/route.ts — External endpoint (Vercel Cron)
- src/app/api/subagents/[id]/route.ts — locking enforcement
- src/lib/subagents.ts — repurposed agent definitions
- src/lib/upgrade-manifest.ts — entry #57
- vercel.json — cron config

## Deploy instructions

The Vercel CLI requires authentication. Three options:

1. Interactive login: run `vercel login` in a terminal, click the link,
   then `vercel --prod --yes` from /home/z/my-project

2. Token: create a token at https://vercel.com/account/tokens, then:
   export VERCEL_TOKEN="your-token-here"
   cd /home/z/my-project
   vercel --prod --yes --token $VERCEL_TOKEN

3. Git push: add a GitHub remote, push, let Vercel auto-deploy.

## Verification (after deploy)

curl https://agent007-ai.vercel.app/api/system/manifest | jq .totalUpgrades
# should be 57

curl https://agent007-ai.vercel.app/api/subagents | jq .subagents[].name
# should include "QA Monitor" and "External Monitor"

curl https://agent007-ai.vercel.app/api/monitor/qa | jq .ok,.monitor,.tier
# should be true,"qa",1-4

curl https://agent007-ai.vercel.app/api/monitor/external | jq .ok,.monitor,.endpointCount
# should be true,"external",10

## Upgrade metrics

- Total upgrades: 54 (was 56, +1 = #57)
- Total tools: 567 (unchanged)
- Total subagents: 18 (unchanged)
- New cron jobs: 2 (QA hourly + External every 30 min)
- Permanently locked agents: 2 (testfast2, fasttest3)
- Owner alert email: antonio.can2022@hotmail.com