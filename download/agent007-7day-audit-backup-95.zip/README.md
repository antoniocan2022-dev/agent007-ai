# Agent007 AI — Owner Backup

Generated: 2026-07-18T16:57:39.844Z
Label: 7day-audit-upgrade95

## Contents

1. agent007-backup-2026-07-18T16-57-39-093Z-7day-audit-upgrade95.json — full structured backup
   - All 33 DB tables (or empty if DB unavailable)
   - All 91 permanent upgrades
   - Capabilities snapshot
   - Config metadata

2. Source files (local dev only — Vercel doesn't bundle them):
   - src/lib/agent.ts
   - src/lib/orchestrator.ts
   - src/lib/tools.ts
   - src/lib/subagents.ts
   - src/middleware.ts
   - src/app/api/owner-backup/route.ts
   - vercel.json
   - prisma/schema.prisma
   - package.json
   - + more

## Auth

This backup was downloaded via /api/owner-backup?token=<OWNER_BACKUP_TOKEN>
Only the owner with the correct token can download backups.

## Stats

- Database tables: 33
- Total rows: 2128
- Upgrades: 91
- JSON size: 4.64 MB