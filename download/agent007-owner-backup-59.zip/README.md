# Agent007 AI — Owner-Only Backup (Upgrade #59)

Generated: 2026-07-12T15:15:35.548Z
Git commit: 589f78755739bcadd85c51b1f92e9bac6793564a

## 🔐 Owner-only access

This backup is for the OWNER ONLY. It is NOT publicly accessible.

After deploy, download fresh backups from production using:

JSON: https://agent007-ai.vercel.app/api/owner-backup?token=agent007-owner-backup-2024-antonio-can-2022&format=json
ZIP:  https://agent007-ai.vercel.app/api/owner-backup?token=agent007-owner-backup-2024-antonio-can-2022&format=zip

## How the owner-only auth works

1. Token-based: URL contains ?token=OWNER_BACKUP_TOKEN
2. Constant-time comparison (prevents timing attacks)
3. Token NOT logged in server logs
4. 403 Forbidden on missing/wrong token
5. public/backup/ files DELETED — no public access
6. /api/backup requires login (session-based)
7. Only /api/owner-backup is publicly reachable (but token-protected)

## To change the token

1. Go to Vercel → Project Settings → Environment Variables
2. Add: OWNER_BACKUP_TOKEN = <your-new-token>
3. Redeploy
4. Use the new token in the URL

## What was fixed (Upgrade #59)

Owner complaint: "non of the link for download are working fix them but only the ownwer me can download it."

Root causes:
1. Auth middleware blocked /api/backup (307 redirect to /login)
2. No token-based auth option — only session-based
3. public/backup/ files were globally accessible (security hole)
4. NONE of the previous links worked because production wasn't deployed

Fixes:
1. NEW /api/owner-backup endpoint with token auth
2. REVERTED middleware: /api/backup requires session (owner-only via login)
3. DELETED public/backup/ files (security hole closed)
4. Whitelisted /api/owner-backup in middleware (token-protected)

## Files in this ZIP

- agent007-owner-backup-59.json — full structured backup
- super-agent-audit-prompt.md — prompt to paste into Agent007 chat for Phase 5
- src/middleware.ts — auth whitelist (with owner-backup added)
- src/app/api/owner-backup/route.ts — NEW token-based backup endpoint
- src/app/api/health/route.ts — public health endpoint
- src/lib/db.ts — DATABASE_URL default fallback
- src/lib/backup-functions.ts — graceful degradation
- src/lib/subagents.ts — 18 subagents incl. QA Monitor + External Monitor
- src/lib/monitor-agents.ts — monitor engine
- src/app/api/monitor/qa/route.ts — QA endpoint (Vercel Cron)
- src/app/api/monitor/external/route.ts — External endpoint (Vercel Cron)
- src/app/api/subagents/[id]/route.ts — NEVER_DISABLE_IDS enforcement
- src/lib/upgrade-manifest.ts — entries #57 + #58 + #59
- src/lib/agent.ts — super agent loop (no tool restrictions)
- src/lib/orchestrator.ts — orchestrator (no tool restrictions)
- src/lib/tools.ts — TOOL_REGISTRY (567 tools)
- vercel.json — 3 cron jobs
- prisma/schema.prisma — DB schema
- audit/EXHAUSTIVE-AUDIT-2026-07-12.md — full audit report

## Deploy instructions

Production is currently on an older build (totalUpgrades=53). All fixes
from upgrades #57 + #58 + #59 are committed but not yet deployed.

To deploy:
  1. cd /home/z/my-project
  2. vercel login   (opens browser, authorize the CLI)
  3. vercel --prod --yes   (build ~50s + deploy ~1m)

## Verification commands (after deploy)

# No token → 403 Forbidden
curl -s -o /dev/null -w "%{http_code}\n" "https://agent007-ai.vercel.app/api/owner-backup"

# Wrong token → 403 Forbidden
curl -s -o /dev/null -w "%{http_code}\n" "https://agent007-ai.vercel.app/api/owner-backup?token=wrong"

# Right token → 200 + JSON download
curl -s -o /dev/null -w "%{http_code}\n" "https://agent007-ai.vercel.app/api/owner-backup?token=agent007-owner-backup-2024-antonio-can-2022&format=json"

# Right token → 200 + ZIP download
curl -s -o /dev/null -w "%{http_code}\n" "https://agent007-ai.vercel.app/api/owner-backup?token=agent007-owner-backup-2024-antonio-can-2022&format=zip"

# Manifest should show 59 upgrades
curl -s https://agent007-ai.vercel.app/api/system/manifest | jq .totalUpgrades

## Metrics

- Total upgrades: 56 (was 53, +6 = upgrades #54-#59)
- Total tools: 567 (unchanged)
- Total subagents: 18 (unchanged)
- Permanently locked agents: 2 (testfast2, fasttest3)
- Owner-only backup endpoint: /api/owner-backup (token auth)
- Public backup files: REMOVED (security hole closed)
- Vercel cron jobs: 3 (schedules/tick + monitor/qa + monitor/external)