/**
 * /api/team/[leaderId] — UPGRADE #97
 * Direct communication with a pod leader.
 * Owner can ask a specific leader for reports, status, or task execution.
 *
 * GET  /api/team/[leaderId]?action=status — get leader's pod status
 * POST /api/team/[leaderId] — send message directly to leader
 *
 * Leaders: scout, aurora, echo, forge, pulse, developer, cybersecurity_r
 */
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { runSubagent, getAllSubagents } from '@/lib/subagents'
import { POD_STRUCTURE, getPodsWithStats, getPodWithStats } from '@/lib/pod-structure'

export const dynamic = 'force-dynamic'
export const maxDuration = 120

export async function GET(req: NextRequest, { params }: { params: Promise<{ leaderId: string }> }) {
  const { leaderId: rawLeaderId } = await params
  const leaderId = rawLeaderId?.toLowerCase()
  const action = new URL(req.url).searchParams.get('action') ?? 'status'

  if (!leaderId || !POD_STRUCTURE[leaderId]) {
    return NextResponse.json({
      ok: false,
      error: `Unknown leader. Available: ${Object.keys(POD_STRUCTURE).join(', ')}`,
    }, { status: 400 })
  }

  if (action === 'status') {
    // Computed live from each member's real allowedTools — no more
    // hardcoded toolCount: 667 that never matched reality.
    const stats = await getPodWithStats(leaderId)
    if (!stats) {
      return NextResponse.json({ ok: false, error: `Could not compute stats for ${leaderId}` }, { status: 500 })
    }
    return NextResponse.json({ ok: true, pod: stats })
  }

  if (action === 'pods') {
    // Return all pods for the dashboard. toolCount/realToolCount/virtualToolCount
    // are computed from subagents.ts + the same REAL_EXECUTABLE_TOOLS list the
    // reality-check page uses, so this can never silently drift out of sync again.
    const pods = await getPodsWithStats()
    return NextResponse.json({ ok: true, pods })
  }

  return NextResponse.json({ ok: false, error: 'Unknown action' }, { status: 400 })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ leaderId: string }> }) {
  const { leaderId: rawLeaderId } = await params
  const leaderId = rawLeaderId?.toLowerCase()

  if (!leaderId || !POD_STRUCTURE[leaderId]) {
    return NextResponse.json({
      ok: false,
      error: `Unknown leader. Available: ${Object.keys(POD_STRUCTURE).join(', ')}`,
    }, { status: 400 })
  }

  const body = await req.json().catch(() => ({}))
  const { message } = body

  if (!message) {
    return NextResponse.json({ ok: false, error: 'Missing "message"' }, { status: 400 })
  }

  const pod = POD_STRUCTURE[leaderId]

  // Dispatch to the leader subagent
  try {
    const allSubs = await getAllSubagents({ includeDisabled: false })
    const sub = allSubs.find((s: any) =>
      s.id === leaderId || s.name.toLowerCase() === pod.leader.toLowerCase()
    )

    if (!sub) {
      return NextResponse.json({
        ok: false,
        error: `Leader ${pod.leader} not found or disabled`,
      }, { status: 404 })
    }

    const result = await runSubagent({
      subagentId: sub.id,
      task: `[DIRECT FROM OWNER] ${message}\n\nContext: You are the LEADER of ${pod.name} pod. Your team: ${pod.members.join(', ')}. Focus: ${pod.focus}. Provide a direct, actionable response. If you need your team members, mention which ones you'd dispatch and why.`,
      dispatchId: `leader_${Date.now()}`,
      attachments: [],
      language: 'en',
      emit: async () => {},
      parentConversationId: 'leader-chat',
    })

    return NextResponse.json({
      ok: true,
      leader: pod.leader,
      pod: pod.name,
      message: message,
      response: result.answer,
    })
  } catch (e: any) {
    return NextResponse.json({
      ok: false,
      error: e?.message ?? 'Failed to dispatch to leader',
    }, { status: 500 })
  }
}
