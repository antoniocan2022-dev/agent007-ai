/**
 * src/lib/pod-structure.ts
 *
 * SINGLE SOURCE OF TRUTH for pod/team membership + focus + color.
 *
 * Before this file existed, the same 8 pods were defined three separate
 * times, independently, and had drifted out of sync with each other:
 *   - src/app/api/team/[leaderId]/route.ts  (POD_STRUCTURE, hardcoded toolCount: 667)
 *   - src/app/pods/route.ts                 (PODS, hardcoded "667 tools",
 *                                             ECHO team had only 1 member listed
 *                                             and a 99% target instead of 92%)
 *   - src/components/agent/tabs/pods-tab.tsx (static fallback array,
 *                                             hardcoded toolCount: 463)
 *
 * Every consumer should import POD_STRUCTURE and getPodsWithStats() from
 * HERE instead of keeping its own copy. Tool counts are now computed live
 * from the actual per-agent `allowedTools` arrays in subagents.ts — not
 * guessed or hardcoded.
 */
import { getAllSubagents, type Subagent } from '@/lib/subagents'
import { REAL_EXECUTABLE_TOOLS } from '@/lib/reality-action-mode'

export interface PodDefinition {
  name: string
  leader: string
  members: string[]
  focus: string
  color: string
  target?: string
}

export const POD_STRUCTURE: Record<string, PodDefinition> = {
  scout: {
    name: 'Intelligence & Research',
    leader: 'SCOUT',
    members: ['HUNT', 'QUANTUM'],
    focus: 'Find opportunities, validate demand, research competitors',
    color: '#38bdf8',
  },
  aurora: {
    name: 'Creation & Design',
    leader: 'AURORA',
    members: ['QUILL', 'PRISM', 'VERTEX'],
    focus: 'Create content, design products, build affiliate funnels',
    color: '#00f0ff',
  },
  echo: {
    name: 'Quality Assurance & Testing',
    leader: 'ECHO',
    members: ['PULSE', 'Developer', 'Cybersecurity R', 'QA Monitor', 'External Monitor'],
    focus: 'Test, verify, score quality, ensure 92 target, monitor systems, fix infrastructure, security response',
    color: '#818cf8',
  },
  forge: {
    name: 'Engineering & Implementation',
    leader: 'FORGE',
    members: ['Developer', 'TRADER'],
    focus: 'Build, deploy, fix infrastructure, execute trades',
    color: '#fb923c',
  },
  pulse: {
    name: 'Monitoring & Operations',
    leader: 'PULSE',
    members: ['External Monitor', 'THE BANKER', 'Performance Analyst'],
    focus: 'Monitor systems, track KPIs, financial monitoring, weekly $ contribution board',
    color: '#fb7185',
  },
  developer: {
    name: 'System Health & Infrastructure',
    leader: 'Developer',
    members: ['QA Monitor', 'External Monitor'],
    focus: 'Tool health, API monitoring, infrastructure repair',
    color: '#10b981',
  },
  cybersecurity_r: {
    name: 'Compliance & Security',
    leader: 'Cybersecurity R',
    members: ['LEGAL', 'Cybersecurity A', 'THE BANKER'],
    focus: 'Legal compliance, tax strategy, security auditing',
    color: '#3b82f6',
  },
  revenue: {
    name: 'Revenue (Passive Income)',
    leader: 'QUANTUM + AURORA',
    members: ['TRADER', 'THE BANKER', 'PULSE'],
    focus: 'Owns all passive income streams: affiliate, SaaS, yield, digital products. Tracks real vs projected income via income_reality_check.',
    color: '#fbbf24',
    target: '$20K/month',
  },
}

export interface PodStats {
  id: string
  name: string
  leader: string
  members: string[]
  focus: string
  color: string
  target?: string
  /** Total distinct tools across the leader + all members. Computed live. */
  toolCount: number
  /** Of toolCount, how many are confirmed to run real code / real API calls. */
  realToolCount: number
  /** toolCount - realToolCount. Narrated/instruction-only tools. */
  virtualToolCount: number
  status: 'ready' | 'partial'
}

function findByDisplayName(all: Subagent[], displayName: string): Subagent | undefined {
  const target = displayName.trim().toLowerCase()
  return all.find((s) => s.name.trim().toLowerCase() === target)
}

/**
 * Resolve a pod's leader + members to their real Subagent records, union
 * their allowedTools, and classify each tool as real vs virtual using the
 * same REAL_EXECUTABLE_TOOLS list the /reality-check page uses — so this
 * number can never drift out of sync with what "reality check" reports
 * elsewhere in the app.
 */
export async function getPodsWithStats(): Promise<PodStats[]> {
  const allSubagents = await getAllSubagents({ includeDisabled: false })
  const realSet = new Set(REAL_EXECUTABLE_TOOLS)

  return Object.entries(POD_STRUCTURE).map(([id, pod]) => {
    const memberNames = [pod.leader, ...pod.members]
    const resolved = memberNames
      .map((n) => findByDisplayName(allSubagents, n))
      .filter((s): s is Subagent => Boolean(s))

    const missing = memberNames.filter((n) => !findByDisplayName(allSubagents, n))

    const toolSet = new Set<string>()
    for (const agent of resolved) {
      for (const tool of agent.allowedTools) toolSet.add(tool)
    }

    const realCount = [...toolSet].filter((t) => realSet.has(t)).length

    return {
      id,
      name: pod.name,
      leader: pod.leader,
      members: pod.members,
      focus: pod.focus,
      color: pod.color,
      target: pod.target,
      toolCount: toolSet.size,
      realToolCount: realCount,
      virtualToolCount: toolSet.size - realCount,
      // If we couldn't resolve every named member to a real Subagent record,
      // surface that instead of silently showing a confident number.
      status: missing.length === 0 ? 'ready' : 'partial',
    }
  })
}

export async function getPodWithStats(podId: string): Promise<PodStats | null> {
  const pods = await getPodsWithStats()
  return pods.find((p) => p.id === podId) ?? null
}
